"""
Django settings for StringeeX Dashboard project.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'change-me-in-production-use-a-long-random-string')

DEBUG = os.getenv('DEBUG', 'True') == 'True'

ALLOWED_HOSTS = [
    host.strip()
    for host in os.getenv(
        'ALLOWED_HOSTS',
        'localhost,127.0.0.1,192.168.155.204,.ngrok-free.dev'
    ).split(',')
]

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'calls',          # our main app
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'calls.auth_middleware.TokenAuthMiddleware',  # token-based dashboard access
]

ROOT_URLCONF = 'stringeex_django.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'stringeex_django.wsgi.application'

# PostgreSQL Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME':     os.getenv('DB_NAME', 'stringeex'),
        'USER':     os.getenv('DB_USER', 'appuser'),
        'PASSWORD': os.getenv('DB_PASSWORD', 'secret'),
        'HOST':     os.getenv('DB_HOST', 'localhost'),
        'PORT':     os.getenv('DB_PORT', '5432'),
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'   # UAE timezone
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# StringeeX API Configuration
STRINGEEX_EMAIL    = os.getenv('STRINGEEX_EMAIL', 'rahulnexora@gmail.com')
STRINGEEX_PASSWORD = os.getenv('STRINGEEX_PASSWORD', 'Abcd@1234')
STRINGEEX_PORTAL   = os.getenv('STRINGEEX_PORTAL', 'bluewave2')   # single-portal fallback
STRINGEEX_PORTALS  = os.getenv('STRINGEEX_PORTALS', '')            # preferred: comma-separated list

# How many minutes between each live sync
STRINGEEX_POLL_INTERVAL_MINUTES = int(os.getenv('POLL_INTERVAL_MINUTES', '4'))

# ── Access Control ─────────────────────────────────────────────────────────────
# Set ACCESS_TOKEN to protect the dashboard with a shared URL token.
# Share the link: https://yourdomain.com/?token=<ACCESS_TOKEN>
# After visiting once, the token is stored in the session — not visible in future URLs.
# Leave blank/unset to disable protection (dev only).
ACCESS_TOKEN = os.getenv('ACCESS_TOKEN', '')

# Sessions stored in DB (default); adjust as needed
SESSION_COOKIE_AGE = 60 * 60 * 24 * 14  # 2 weeks
