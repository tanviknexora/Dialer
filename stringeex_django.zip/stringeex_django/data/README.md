# data/

Place `Team_tradex.xlsx` here.

The file must contain a sheet named **Sheet2** with these columns:

| Dialer     | Dialer Name               | Email                  | Employee code | Full Name | Pool | TL | Vertical |
|------------|---------------------------|------------------------|---------------|-----------|------|----|----------|
| Stringee   | anushka@bluewave.com      | anushka@nexora.live    | E-XXXX        | Anushka   | Meta | … | TradeX   |

Only rows where `Dialer == "Stringee"` are loaded.
Override the path via the `TEAM_XLSX_PATH` environment variable.
