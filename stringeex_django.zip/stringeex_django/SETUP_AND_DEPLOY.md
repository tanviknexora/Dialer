# StringeeX Dashboard — Setup, Data Sync & Deployment Guide

---

## 1. Install Dependencies

```bash
cd stringeex_django
pip install -r requirements.txt
pip install python-dotenv   # if not already in requirements.txt
```

---

## 2. Configure `.env`

Edit `.env` and set your values:

```env
ACCESS_TOKEN=pick-a-long-random-string-here   # e.g. "nx9kQzP2mT4vR7wY"
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,localhost
```

**Generate a strong token:**
```bash
python -c "import secrets; print(secrets.token_urlsafe(24))"
```

---

## 3. Database Setup

```bash
# Run migrations (creates tables)
python manage.py migrate

# Create Django admin superuser (optional)
python manage.py createsuperuser
```

---

## 4. Flush Old Data & Backfill May 1–9

**Step 1 — Wipe all existing records:**
```bash
python manage.py sync_calls --flush
```

**Step 2 — Backfill May 1 to May 9:**
```bash
python manage.py sync_calls --start 2026-05-01 --end 2026-05-09
```

This fetches day by day from the StringeeX API and inserts all records.
Historical records are never overwritten once inserted.

---

## 5. Start the Live 4-Minute Daemon

In a **separate terminal** (or as a systemd service):

```bash
python manage.py sync_calls --daemon --interval 4
```

**What it does:**
- Every 4 minutes: fetches the last 9 minutes from the API (with overlap to avoid gaps).
- For **today's records**: uses `update_or_create` — keeps data current, replaces stale entries.
- For **yesterday and older**: uses `get_or_create` — never overwrites history.
- At midnight UTC, today becomes history automatically.

---

## 6. Run the Web Server

**Development:**
```bash
python manage.py runserver 0.0.0.0:8000
```

**Production (recommended with gunicorn):**
```bash
pip install gunicorn
gunicorn stringeex_django.wsgi:application --bind 0.0.0.0:8000 --workers 2
```

---

## 7. Deployment — Sharing Without Data Leakage

### How the token system works:

1. You set `ACCESS_TOKEN=your_secret_token` in `.env`.
2. You share this link **once** with the person:
   ```
   https://yourdomain.com/?token=your_secret_token
   ```
3. When they open the link, the token is **verified and stored in their browser session**.
4. The token disappears from the URL — future visits to `https://yourdomain.com/` work normally.
5. **Your manager never sees** API credentials, DB passwords, or raw data endpoints.
6. Sessions expire after **2 weeks** — they can re-use the original link to re-authenticate.

### To revoke access:
- Change `ACCESS_TOKEN` in `.env` and restart the server.
- All existing sessions are invalidated immediately.

### Separate link per person:
You can share the same token with multiple people, or generate different tokens
for different users (would require minor code change to support multiple tokens).

---

## 8. Run as Systemd Services (Production)

**Web server** — `/etc/systemd/system/stringeex-web.service`:
```ini
[Unit]
Description=StringeeX Dashboard Web
After=network.target postgresql.service

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/stringeex_django
EnvironmentFile=/home/ubuntu/stringeex_django/.env
ExecStart=/home/ubuntu/venv/bin/gunicorn stringeex_django.wsgi:application \
    --bind 0.0.0.0:8000 --workers 2
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

**Sync daemon** — `/etc/systemd/system/stringeex-sync.service`:
```ini
[Unit]
Description=StringeeX Live Sync Daemon
After=network.target postgresql.service

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/stringeex_django
EnvironmentFile=/home/ubuntu/stringeex_django/.env
ExecStart=/home/ubuntu/venv/bin/python manage.py sync_calls --daemon --interval 4
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable stringeex-web stringeex-sync
sudo systemctl start stringeex-web stringeex-sync
sudo systemctl status stringeex-web stringeex-sync
```

---

## 9. Nginx Reverse Proxy (optional)

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location /static/ {
        alias /home/ubuntu/stringeex_django/staticfiles/;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
python manage.py collectstatic --noinput
sudo nginx -t && sudo systemctl reload nginx
```

---

## 10. Quick Reference Commands

| Task | Command |
|------|---------|
| Flush all data | `python manage.py sync_calls --flush` |
| Backfill date range | `python manage.py sync_calls --start 2026-05-01 --end 2026-05-09` |
| Start live daemon | `python manage.py sync_calls --daemon --interval 4` |
| Import CSV | `python manage.py sync_calls --csv /path/to/report.csv` |
| One-time sync (last 2h) | `python manage.py sync_calls` |
| Generate access token | `python -c "import secrets; print(secrets.token_urlsafe(24))"` |

---

## 11. Bug Fixes Applied

1. **TL filter not working** — Fixed in two places:
   - `applyFilters()` now calls `filterAgentList()` to re-render the sidebar by TL.
   - `filterAgentList()` now applies `state.tl` and `state.pool` to filter sidebar agents.
   - After `loadTeamList()` completes, `filterAgentList()` is called so any pre-selected filter applies immediately.

2. **KPI stats used `days=1` (rolling 24h) instead of selected date** — Fixed:
   - `api/stats/` now accepts `?date=YYYY-MM-DD` and uses that date's exact range.
   - Frontend now passes `date=` instead of `days=1` when fetching KPIs.

3. **Smart upsert for live data** — New behaviour:
   - Today's records: `update_or_create` (always current).
   - Historical records: `get_or_create` (never overwritten).
