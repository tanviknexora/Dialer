"""
python manage.py reenrich_teams

Re-applies TL / Pool / Full Name from Team_tradex.xlsx to every CallRecord row.
Run this once after fixing the lookup (or after updating the Excel).
"""
from django.core.management.base import BaseCommand
from calls.models import CallRecord
from calls.team_lookup import reload_team_lookup, enrich_record


class Command(BaseCommand):
    help = 'Re-enrich all CallRecord rows with fresh team metadata from the Excel'

    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true',
                            help='Show stats only, do not write to DB')

    def handle(self, *args, **options):
        dry = options['dry_run']
        self.stdout.write('Reloading team lookup …')
        lookup = reload_team_lookup()
        self.stdout.write(self.style.SUCCESS(f'  {len(lookup)} prefix keys loaded'))

        total = CallRecord.objects.count()
        self.stdout.write(f'Processing {total} records …')

        updated = 0
        batch   = []
        for rec in CallRecord.objects.all().iterator(chunk_size=500):
            info = enrich_record(rec.account_name)
            fn  = info['full_name']     or None
            ec  = info['employee_code'] or None
            po  = info['pool']          or None
            tl  = info['tl']            or None
            vt  = info['vertical']      or None

            if (rec.full_name, rec.employee_code, rec.pool, rec.tl, rec.vertical) != (fn, ec, po, tl, vt):
                rec.full_name     = fn
                rec.employee_code = ec
                rec.pool          = po
                rec.tl            = tl
                rec.vertical      = vt
                batch.append(rec)
                updated += 1

            if len(batch) >= 500 and not dry:
                CallRecord.objects.bulk_update(
                    batch, ['full_name', 'employee_code', 'pool', 'tl', 'vertical']
                )
                batch = []

        if batch and not dry:
            CallRecord.objects.bulk_update(
                batch, ['full_name', 'employee_code', 'pool', 'tl', 'vertical']
            )

        tag = '[DRY RUN] ' if dry else ''
        self.stdout.write(self.style.SUCCESS(
            f'{tag}Done — {updated} records updated out of {total}'
        ))
