"""
Management command: sync_calls

Usage:
  # One-time sync of the last 2 hours (from StringeeX API):
  python manage.py sync_calls

  # Sync a custom range of hours:
  python manage.py sync_calls --hours 6

  # Run as a continuous daemon (polls every N minutes):
  python manage.py sync_calls --daemon
  python manage.py sync_calls --daemon --interval 10

  # Backfill a specific date range:
  python manage.py sync_calls --start 2025-04-01 --end 2025-04-23

  # Import directly from a downloaded CSV (new Stringee API export format):
  python manage.py sync_calls --csv /path/to/call_report_20260508_20260508.csv
"""

import time
import logging
import math
from datetime import datetime, timezone, timedelta

import pandas as pd

from django.core.management.base import BaseCommand
from django.conf import settings

from calls.models import CallRecord, DIRECTION_MAP, _secs_to_hhmmss
from calls.team_lookup import enrich_record
from calls.stringeex_service import (
    fetch_recent_calls, fetch_calls_for_range,
    get_auth_token, StringeeXError,
)

logger = logging.getLogger(__name__)


# ── Shared helpers ─────────────────────────────────────────────────────────────

def _direction_from_int(val) -> str:
    """Map API integer direction (0/1) to string ('outbound'/'inbound')."""
    try:
        return DIRECTION_MAP.get(int(val), 'outbound')
    except (TypeError, ValueError):
        # Already a string (old API format) or unknown
        if isinstance(val, str) and val in ('inbound', 'outbound', 'internal'):
            return val
        return 'outbound'


def upsert_records(rows: list[dict]) -> tuple[int, int]:
    """
    Insert new records from API rows; skip exact duplicates (by PK).

    Key changes vs old version:
    - direction is now an int (0/1) from the API → converted to string
    - end_call_reason 'CAN_NOT_MAKE_CALL' rows are skipped (mirrors notebook filter)
    - agent team metadata enriched via team_lookup
    - queue duration is derived as: duration − talk_duration

    Returns (new_count, skipped_count).
    """
    new_count = skipped = 0

    for row in rows:
        call_id = str(row.get('id', '')).strip()
        if not call_id:
            continue

        # ── Notebook filter: skip CAN_NOT_MAKE_CALL ───────────────────
        end_reason = str(row.get('end_call_reason') or '').strip()
        if end_reason == 'CAN_NOT_MAKE_CALL':
            skipped += 1
            continue

        # ── Direction mapping ──────────────────────────────────────────
        direction = _direction_from_int(row.get('direction'))

        # ── Duration fields ────────────────────────────────────────────
        duration        = int(row.get('duration') or 0)
        talk_duration   = int(row.get('talk_duration') or 0)
        raw_answer      = row.get('answer_duration')
        answer_duration = float(raw_answer) if (raw_answer is not None and not _is_nan(raw_answer)) else 0.0

        # ── Team enrichment ────────────────────────────────────────────
        account_name = str(row.get('account_name') or '').strip()
        team_info    = enrich_record(account_name)

        obj, created = CallRecord.objects.get_or_create(
            id=call_id,
            defaults={
                'account_name':    account_name,
                'direction':       direction,
                'start_time_ms':   row.get('start_time'),
                'end_time_ms':     row.get('end_time'),
                'duration':        duration,
                'talk_duration':   talk_duration,
                'answer_duration': answer_duration,
                'end_call_reason': end_reason or None,
                'customer_number': str(row.get('customer_number') or '').strip() or None,
                'stringee_number': str(row.get('stringee_number') or '').strip() or None,
                # Team fields
                'full_name':       team_info['full_name'] or None,
                'employee_code':   team_info['employee_code'] or None,
                'pool':            team_info['pool'] or None,
                'tl':              team_info['tl'] or None,
                'vertical':        team_info['vertical'] or None,
            }
        )
        if created:
            new_count += 1
        else:
            skipped += 1

    return new_count, skipped


def _is_nan(val) -> bool:
    try:
        return math.isnan(float(val))
    except (TypeError, ValueError):
        return False


# ── CSV import ─────────────────────────────────────────────────────────────────

def import_from_csv(path: str) -> tuple[int, int]:
    """
    Import call records from a Stringee API CSV export.

    Expected columns (as in call_report_YYYYMMDD_YYYYMMDD.csv):
        id, account_name, direction, start_time, end_time,
        duration, talk_duration, answer_duration,
        end_call_reason, customer_number, stringee_number

    The notebook logic applied here:
        1. Filter out 'CAN_NOT_MAKE_CALL' rows.
        2. Map direction int → string.
        3. Compute queue_duration = duration − talk_duration  (stored implicitly).
        4. Convert start_time / end_time (unix ms int) → stored as-is in start_time_ms.
        5. Enrich with team metadata via account_name lookup.
    """
    df = pd.read_csv(path, low_memory=False)

    # Rename CSV columns → API-style keys so upsert_records can handle them
    df = df.rename(columns={
        'start_time': 'start_time',   # already correct
        'end_time':   'end_time',
    })

    rows = df.to_dict(orient='records')
    return upsert_records(rows)


# ── Management command ─────────────────────────────────────────────────────────

class Command(BaseCommand):
    help = 'Sync call records from StringeeX (API or CSV) into the database'

    def add_arguments(self, parser):
        parser.add_argument(
            '--hours', type=int, default=2,
            help='Hours to look back for recent sync (default: 2)',
        )
        parser.add_argument(
            '--daemon', action='store_true',
            help='Run as a continuous daemon (keeps polling)',
        )
        parser.add_argument(
            '--interval', type=int,
            default=getattr(settings, 'STRINGEEX_POLL_INTERVAL_MINUTES', 5),
            help='Polling interval in minutes for daemon mode',
        )
        parser.add_argument(
            '--start', type=str,
            help='Start date for backfill (YYYY-MM-DD)',
        )
        parser.add_argument(
            '--end', type=str,
            help='End date for backfill (YYYY-MM-DD)',
        )
        parser.add_argument(
            '--csv', type=str,
            help='Path to a downloaded Stringee CSV export to import directly',
        )

    def handle(self, *args, **options):
        # ── CSV import mode ───────────────────────────────────────────────
        if options.get('csv'):
            self._import_csv(options['csv'])
            return

        # ── Backfill mode ─────────────────────────────────────────────────
        if options['start'] or options['end']:
            self._backfill(options)
            return

        # ── Daemon mode ───────────────────────────────────────────────────
        if options['daemon']:
            self._run_daemon(options)
            return

        # ── One-shot mode ─────────────────────────────────────────────────
        self._sync_once(options['hours'])

    # ── Private helpers ───────────────────────────────────────────────────────

    def _import_csv(self, path: str):
        self.stdout.write(self.style.NOTICE(f'📂 Importing CSV: {path}'))
        try:
            new, skipped = import_from_csv(path)
            self.stdout.write(self.style.SUCCESS(
                f'✅ CSV import done — {new} new records, {skipped} skipped '
                f'(duplicates or CAN_NOT_MAKE_CALL).'
            ))
        except FileNotFoundError:
            self.stderr.write(self.style.ERROR(f'❌ File not found: {path}'))
        except Exception as exc:
            self.stderr.write(self.style.ERROR(f'❌ CSV import failed: {exc}'))

    def _sync_once(self, hours_back: int):
        self.stdout.write(self.style.NOTICE(
            f'🔄 Syncing last {hours_back}h of calls from StringeeX API...'
        ))
        try:
            rows = fetch_recent_calls(hours_back=hours_back)
            new, skipped = upsert_records(rows)
            self.stdout.write(self.style.SUCCESS(
                f'✅ Done — {new} new records saved, {skipped} skipped.'
            ))
        except StringeeXError as e:
            self.stderr.write(self.style.ERROR(f'❌ Sync failed: {e}'))

    def _run_daemon(self, options):
        interval = options['interval']
        hours    = options['hours']
        self.stdout.write(self.style.WARNING(
            f'🚀 Daemon started — polling every {interval} minute(s). Press Ctrl+C to stop.'
        ))
        while True:
            self._sync_once(hours)
            self.stdout.write(f'   ⏱  Next sync in {interval} minute(s)...\n')
            time.sleep(interval * 60)

    def _backfill(self, options):
        if not options['start'] or not options['end']:
            self.stderr.write(self.style.ERROR(
                '❌ Provide both --start and --end for backfill.'
            ))
            return
        try:
            start_dt = datetime.strptime(options['start'], '%Y-%m-%d').replace(
                tzinfo=timezone.utc)
            end_dt   = datetime.strptime(options['end'], '%Y-%m-%d').replace(
                hour=23, minute=59, second=59, tzinfo=timezone.utc)
        except ValueError as e:
            self.stderr.write(self.style.ERROR(f'❌ Date parse error: {e}'))
            return

        self.stdout.write(self.style.NOTICE(
            f'📦 Backfilling {options["start"]} → {options["end"]}...'
        ))
        try:
            token, base_url = get_auth_token()
            rows = fetch_calls_for_range(token, base_url, start_dt, end_dt)
            new, skipped = upsert_records(rows)
            self.stdout.write(self.style.SUCCESS(
                f'✅ Backfill complete — {new} new records, {skipped} skipped.'
            ))
        except StringeeXError as e:
            self.stderr.write(self.style.ERROR(f'❌ Backfill failed: {e}'))
