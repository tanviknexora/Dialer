"""
Management command: sync_calls

Usage:
  python manage.py sync_calls --flush                              # wipe DB only, no auto-sync
  python manage.py sync_calls --flush --start 2026-05-01 --end 2026-05-09  # wipe then backfill
  python manage.py sync_calls --start 2026-05-01 --end 2026-05-09          # backfill only
  python manage.py sync_calls --daemon                             # live 4-min polling
  python manage.py sync_calls                                      # one-shot last 2h
  python manage.py sync_calls --csv /path/to/report.csv
"""

import time
import logging
import math
from datetime import datetime, timezone, timedelta, date
from zoneinfo import ZoneInfo

LOCAL_TZ = ZoneInfo('Asia/Kolkata')  # IST (UTC+5:30) — all date logic uses this

import pandas as pd

from django.core.management.base import BaseCommand

from calls.models import CallRecord, DIRECTION_MAP
from calls.team_lookup import enrich_record
from calls.stringeex_service import fetch_all_portals_for_range, StringeeXError

logger = logging.getLogger(__name__)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _direction_from_int(val) -> str:
    try:
        return DIRECTION_MAP.get(int(val), 'outbound')
    except (TypeError, ValueError):
        if isinstance(val, str) and val in ('inbound', 'outbound', 'internal'):
            return val
        return 'outbound'


def _is_nan(val) -> bool:
    try:
        return math.isnan(float(val))
    except (TypeError, ValueError):
        return False


def _is_today_local(start_time_ms) -> bool:
    """True if this call's timestamp falls on today in IST local time."""
    if not start_time_ms:
        return False
    dt = datetime.fromtimestamp(int(start_time_ms) / 1000, tz=LOCAL_TZ)
    return dt.date() == datetime.now(tz=LOCAL_TZ).date()


def upsert_records(rows: list, replace_today: bool = False) -> tuple:
    """
    Smart upsert:
    - replace_today=True  → update_or_create for today's records (live sync).
    - replace_today=False → get_or_create only, never overwrite history (backfill).
    Returns (saved_count, skipped_count).
    """
    saved = skipped = 0

    for row in rows:
        call_id = str(row.get('id', '')).strip()
        if not call_id:
            continue

        end_reason = str(row.get('end_call_reason') or '').strip()
        if end_reason == 'CAN_NOT_MAKE_CALL':
            skipped += 1
            continue

        direction       = _direction_from_int(row.get('direction'))
        duration        = int(row.get('duration') or 0)
        talk_duration   = int(row.get('talk_duration') or 0)
        raw_answer      = row.get('answer_duration')
        answer_duration = float(raw_answer) if (raw_answer is not None and not _is_nan(raw_answer)) else 0.0
        account_name    = str(row.get('account_name') or '').strip()
        team_info       = enrich_record(account_name)
        start_ms        = row.get('start_time')
        end_ms          = row.get('end_time')

        fields = {
            'account_name':    account_name,
            'direction':       direction,
            'start_time_ms':   start_ms,
            'end_time_ms':     end_ms,
            'duration':        duration,
            'talk_duration':   talk_duration,
            'answer_duration': answer_duration,
            'end_call_reason': end_reason or None,
            'customer_number': str(row.get('customer_number') or '').strip() or None,
            'stringee_number': str(row.get('stringee_number') or '').strip() or None,
            'full_name':       team_info['full_name'] or None,
            'employee_code':   team_info['employee_code'] or None,
            'pool':            team_info['pool'] or None,
            'tl':              team_info['tl'] or None,
            'vertical':        team_info['vertical'] or None,
        }

        if replace_today and _is_today_local(start_ms):
            _, created = CallRecord.objects.update_or_create(id=call_id, defaults=fields)
            saved += 1  # count both inserts and updates as saved
        else:
            _, created = CallRecord.objects.get_or_create(id=call_id, defaults=fields)
            if created:
                saved += 1
            else:
                skipped += 1

    return saved, skipped


def import_from_csv(path: str) -> tuple:
    df = pd.read_csv(path, low_memory=False)
    return upsert_records(df.to_dict(orient='records'))


# ── Management command ─────────────────────────────────────────────────────────

class Command(BaseCommand):
    help = 'Sync call records from StringeeX API or CSV'

    def add_arguments(self, parser):
        parser.add_argument('--hours', type=int, default=2,
                            help='Hours to look back for one-shot sync (default: 2)')
        parser.add_argument('--daemon', action='store_true',
                            help='Live daemon — polls every --interval minutes')
        parser.add_argument('--interval', type=int, default=4,
                            help='Poll interval in minutes (default: 4)')
        parser.add_argument('--start', type=str, help='Backfill start date YYYY-MM-DD')
        parser.add_argument('--end',   type=str, help='Backfill end date YYYY-MM-DD')
        parser.add_argument('--csv',   type=str, help='Path to Stringee CSV export')
        parser.add_argument('--flush', action='store_true',
                            help='Delete ALL records first. Combine with --start/--end to backfill after.')

    def handle(self, *args, **options):
        # ── Step 1: Flush if requested ─────────────────────────────────────
        if options.get('flush'):
            count, _ = CallRecord.objects.all().delete()
            self.stdout.write(self.style.WARNING(
                f'Flushed {count} records from the database.'))
            # If ONLY --flush was given (no other action), stop here.
            no_action = (
                not options.get('csv') and
                not options.get('start') and
                not options.get('end') and
                not options.get('daemon')
            )
            if no_action:
                self.stdout.write(self.style.SUCCESS(
                    'Database cleared. Run your desired sync command separately.'))
                return

        # ── Step 2: Dispatch to the right action ───────────────────────────
        if options.get('csv'):
            self._import_csv(options['csv'])

        elif options.get('start') or options.get('end'):
            self._backfill(options)

        elif options.get('daemon'):
            self._run_daemon(options)

        else:
            # Plain `sync_calls` with no flags = one-shot live sync
            self._sync_once(options['hours'], replace_today=True)

    # ── Private methods ────────────────────────────────────────────────────────

    def _import_csv(self, path):
        self.stdout.write(self.style.NOTICE(f'Importing CSV: {path}'))
        try:
            new, skip = import_from_csv(path)
            self.stdout.write(self.style.SUCCESS(
                f'CSV done — {new} saved, {skip} skipped.'))
        except FileNotFoundError:
            self.stderr.write(self.style.ERROR(f'File not found: {path}'))
        except Exception as exc:
            self.stderr.write(self.style.ERROR(f'CSV import failed: {exc}'))

    def _sync_once(self, hours_back, replace_today=False):
        self.stdout.write(self.style.NOTICE(
            f'Syncing last {hours_back}h from all portals…'))
        try:
            now   = datetime.now(tz=timezone.utc)
            start = now - timedelta(hours=hours_back)
            rows  = fetch_all_portals_for_range(start, now)
            new, skip = upsert_records(rows, replace_today=replace_today)
            self.stdout.write(self.style.SUCCESS(
                f'Done — {new} saved/updated, {skip} skipped.'))
        except Exception as e:
            self.stderr.write(self.style.ERROR(f'Sync failed: {e}'))

    def _run_daemon(self, options):
        interval = options['interval']
        self.stdout.write(self.style.WARNING(
            f'Daemon started — polling every {interval} min. Ctrl+C to stop.'))
        while True:
            try:
                now   = datetime.now(tz=timezone.utc)
                start = now - timedelta(minutes=interval + 5)  # overlap to avoid gaps
                rows  = fetch_all_portals_for_range(start, now)
                new, skip = upsert_records(rows, replace_today=True)
                ts = now.strftime('%H:%M:%S UTC')
                self.stdout.write(
                    f'[{ts}] {new} saved/updated, {skip} skipped — next in {interval}m')
            except StringeeXError as e:
                self.stderr.write(self.style.ERROR(f'API error: {e}'))
            except Exception as e:
                self.stderr.write(self.style.ERROR(f'Unexpected error: {e}'))
            time.sleep(interval * 60)

    def _backfill(self, options):
        if not options.get('start') or not options.get('end'):
            self.stderr.write(self.style.ERROR(
                'Provide both --start YYYY-MM-DD and --end YYYY-MM-DD.'))
            return
        try:
            start_dt = datetime.strptime(options['start'], '%Y-%m-%d').replace(tzinfo=LOCAL_TZ)
            end_dt   = datetime.strptime(options['end'],   '%Y-%m-%d').replace(
                hour=23, minute=59, second=59, tzinfo=LOCAL_TZ)
        except ValueError as e:
            self.stderr.write(self.style.ERROR(f'Date parse error: {e}'))
            return

        self.stdout.write(self.style.NOTICE(
            f'Backfilling {options["start"]} → {options["end"]} from all portals…'))

        current   = start_dt
        total_new = total_skip = 0

        while current <= end_dt:
            day_end = current.replace(hour=23, minute=59, second=59)
            if day_end > end_dt:
                day_end = end_dt

            day_label = current.strftime('%Y-%m-%d')
            self.stdout.write(f'  {day_label}…', ending='')
            self.stdout.flush()

            try:
                rows = fetch_all_portals_for_range(current, day_end)
                new, skip = upsert_records(rows, replace_today=False)
                total_new  += new
                total_skip += skip
                self.stdout.write(
                    f' {len(rows)} fetched → {new} new, {skip} skipped')
            except StringeeXError as e:
                self.stdout.write('')
                self.stderr.write(self.style.ERROR(f'  Failed {day_label}: {e}'))

            current = (current + timedelta(days=1)).replace(hour=0, minute=0, second=0)

        self.stdout.write(self.style.SUCCESS(
            f'Backfill complete — {total_new} total new, {total_skip} total skipped.'))
