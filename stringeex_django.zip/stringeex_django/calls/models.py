from django.db import models


DIRECTION_MAP = {0: 'outbound', 1: 'inbound'}


class CallRecord(models.Model):
    DIRECTION_CHOICES = [
        ('inbound',  'Inbound'),
        ('outbound', 'Outbound'),
        ('internal', 'Internal'),
    ]

    # Primary key is StringeeX's own ID
    id               = models.CharField(max_length=128, primary_key=True)

    # account_name is the agent email from the API (e.g. anushka@bluewave.com)
    account_name     = models.CharField(max_length=255, blank=True, null=True)

    # direction stored as string after mapping 0→outbound, 1→inbound
    direction        = models.CharField(max_length=20, choices=DIRECTION_CHOICES,
                                        blank=True, null=True)

    # Raw unix millisecond timestamps from the API
    start_time_ms    = models.BigIntegerField(blank=True, null=True)
    end_time_ms      = models.BigIntegerField(blank=True, null=True)

    # Durations in seconds (from API)
    duration         = models.IntegerField(default=0)   # total call duration
    talk_duration    = models.IntegerField(default=0)   # agent talk time
    answer_duration  = models.FloatField(default=0)     # same as talk for connected calls

    end_call_reason  = models.CharField(max_length=128, blank=True, null=True)
    customer_number  = models.CharField(max_length=64,  blank=True, null=True)
    stringee_number  = models.CharField(max_length=64,  blank=True, null=True)

    # Team-enriched fields (populated from Team_tradex lookup)
    full_name        = models.CharField(max_length=255, blank=True, null=True)
    employee_code    = models.CharField(max_length=64,  blank=True, null=True)
    pool             = models.CharField(max_length=128, blank=True, null=True)
    tl               = models.CharField(max_length=128, blank=True, null=True)
    vertical         = models.CharField(max_length=128, blank=True, null=True)

    # When WE stored this record
    fetched_at       = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering     = ['-start_time_ms']
        verbose_name = 'Call Record'
        verbose_name_plural = 'Call Records'

    def __str__(self):
        return f"{self.direction} | {self.customer_number} | {self.account_name}"

    @property
    def start_datetime(self):
        if self.start_time_ms:
            from datetime import datetime, timezone
            return datetime.fromtimestamp(self.start_time_ms / 1000, tz=timezone.utc)
        return None

    @property
    def queue_duration_secs(self):
        return max((self.duration or 0) - (self.talk_duration or 0), 0)

    @property
    def total_duration_display(self):
        return _secs_to_hhmmss(self.duration or 0)

    @property
    def talk_duration_display(self):
        return _secs_to_hhmmss(self.talk_duration or 0)

    @property
    def queue_duration_display(self):
        return _secs_to_hhmmss(self.queue_duration_secs)

    @property
    def duration_display(self):
        secs = self.talk_duration or self.duration or 0
        mins, s = divmod(secs, 60)
        return f"{mins}m {s:02d}s" if mins else f"{s}s"

    @property
    def is_connected(self):
        return (self.talk_duration or 0) > 0


def _secs_to_hhmmss(secs: int) -> str:
    secs = int(secs or 0)
    h, rem = divmod(secs, 3600)
    m, s   = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"
