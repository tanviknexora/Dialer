"""
team_lookup.py
--------------
Builds a lookup from Team_tradex.xlsx keyed by the prefix-before-@ of an email.

Why prefix matching?
  The API sends account_name = "irfan@bluewave.com"
  Sheet2 Dialer Name column has  "irfan@bluewave.com"   ← exact match, preferred
  Sheet1 Email column has        "irfan@nexora.live"     ← same person, different domain
  Both have prefix "irfan" → one lookup covers both.

Build order (later entries override earlier for the same prefix):
  1. Sheet1 (Email column) — full CRE list, 124 rows
  2. Sheet2 Stringee rows (Dialer Name column) — takes priority because it has
     the bluewave.com address that the API actually sends

This means Sheet2 is authoritative for TL/Pool for Stringee agents, and
Sheet1 covers everyone else (other dialers, OJT, Pull Back, etc.).
"""

import os
import logging
import pandas as pd

logger = logging.getLogger(__name__)

_DEFAULT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)),
    'data',
    'Team_tradex.xlsx',
)
TEAM_XLSX_PATH = os.environ.get('TEAM_XLSX_PATH', _DEFAULT_PATH)

# _CACHE: keyed by lowercase prefix-before-@
_CACHE: dict | None = None


def _pfx(value: str) -> str:
    """Return lowercase text before '@', or the whole string if no '@'."""
    s = str(value or '').strip()
    return s.split('@')[0].strip().lower()


def _clean(val) -> str:
    v = str(val or '').strip()
    return '' if v in ('', '#N/A', 'nan', 'None', 'NaN', 'nan') else v


def _build_lookup(path: str) -> dict:
    lookup: dict = {}

    try:
        xf = pd.ExcelFile(path)
    except FileNotFoundError:
        logger.warning("team_lookup: xlsx not found at %s — enrichment disabled.", path)
        return {}
    except Exception as exc:
        logger.error("team_lookup: cannot open %s: %s", path, exc)
        return {}

    # ── Pass 1: Sheet1 — full CRE list keyed on Email (nexora.live) ──────────
    # Columns: Email, Employee Code, Unnamed: 2 (Full Name), Pool, TL, Vertical
    if 'Sheet1' in xf.sheet_names:
        try:
            df1 = xf.parse('Sheet1')
            for _, row in df1.iterrows():
                key = _pfx(row.get('Email', ''))
                if not key or key in ('nan', 'none', '0'):
                    continue
                lookup[key] = {
                    'full_name':     _clean(row.get('Unnamed: 2', '') or row.get('Full Name', '')),
                    'employee_code': _clean(row.get('Employee Code', '') or row.get('Employee code', '')),
                    'pool':          _clean(row.get('Pool', '')),
                    'tl':            _clean(row.get('TL', '')),
                    'vertical':      _clean(row.get('Vertical', '')),
                }
            logger.info("team_lookup Sheet1: %d prefix keys.", len(lookup))
        except Exception as exc:
            logger.error("team_lookup: Sheet1 error: %s", exc)

    # ── Pass 2: Sheet2 Stringee rows — keyed on Dialer Name (bluewave.com) ───
    # These OVERRIDE Sheet1 for the same prefix so bluewave.com TL/pool wins.
    # Columns: Dialer, Dialer Name, Email, Employee code, Full Name, Pool, TL, Vertical
    if 'Sheet2' in xf.sheet_names:
        try:
            df2 = xf.parse('Sheet2')
            stringee = df2[
                df2['Dialer'].astype(str).str.strip().str.lower().isin(['stringee', 'strigee'])
            ].copy()
            added = 0
            for _, row in stringee.iterrows():
                # Key on Dialer Name prefix (e.g. "irfan" from "irfan@bluewave.com")
                key = _pfx(row.get('Dialer Name', ''))
                if not key or key in ('nan', 'none'):
                    continue
                meta = {
                    'full_name':     _clean(row.get('Full Name', '')),
                    'employee_code': _clean(row.get('Employee code', '')),
                    'pool':          _clean(row.get('Pool', '')),
                    'tl':            _clean(row.get('TL', '')),
                    'vertical':      _clean(row.get('Vertical', '')),
                }
                # Fill blanks from Sheet1 if Sheet2 row has missing TL/pool
                if key in lookup:
                    existing = lookup[key]
                    for field in ('full_name', 'employee_code', 'pool', 'tl', 'vertical'):
                        if not meta[field] and existing.get(field):
                            meta[field] = existing[field]
                lookup[key] = meta
                added += 1
            logger.info("team_lookup Sheet2: %d Stringee rows (total %d keys).", added, len(lookup))
        except Exception as exc:
            logger.error("team_lookup: Sheet2 error: %s", exc)

    return lookup


def get_team_lookup() -> dict:
    """Return cached lookup (built on first call)."""
    global _CACHE
    if _CACHE is None:
        _CACHE = _build_lookup(TEAM_XLSX_PATH)
    return _CACHE


def reload_team_lookup() -> dict:
    """Force reload from disk."""
    global _CACHE
    _CACHE = _build_lookup(TEAM_XLSX_PATH)
    return _CACHE


def enrich_record(account_name: str | None) -> dict:
    """
    Look up team metadata for an API account_name like 'irfan@bluewave.com'.
    Matches on the prefix before '@' so domain differences don't matter.
    """
    lookup = get_team_lookup()
    key = _pfx(account_name or '')
    return lookup.get(key, {
        'full_name': '', 'employee_code': '', 'pool': '', 'tl': '', 'vertical': '',
    })


def all_excel_agents() -> list[dict]:
    """
    All agents from the Excel as a flat list, for the team-list API endpoint.
    Returns dicts with keys: account_name, full_name, tl, pool, employee_code, vertical.
    """
    lookup = get_team_lookup()
    agents = []
    for prefix, meta in lookup.items():
        agents.append({
            'account_name':  prefix,        # prefix used for matching
            'full_name':     meta['full_name'] or prefix,
            'tl':            meta['tl'],
            'pool':          meta['pool'],
            'employee_code': meta['employee_code'],
            'vertical':      meta['vertical'],
        })
    return agents
