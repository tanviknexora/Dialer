"""
Simple token-based access control.

Set ACCESS_TOKEN in .env.  Users visit /?token=<ACCESS_TOKEN> once —
it's stored in the session.  All subsequent requests work until the
session expires (default 2 weeks).

To share the dashboard: give them the URL with ?token=<your_token>
They open it once, token is stored in session — no further exposure.
Your manager never sees the URL with the token embedded.
"""
from django.http import HttpResponseForbidden
from django.conf import settings


BYPASS_PATHS = {'/admin/', '/api/'}


class TokenAuthMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.token = getattr(settings, 'ACCESS_TOKEN', None)

    def __call__(self, request):
        # If ACCESS_TOKEN is not configured, allow all (dev mode)
        if not self.token:
            return self.get_response(request)

        # Always allow Django admin
        if request.path.startswith('/admin/'):
            return self.get_response(request)

        # Allow API endpoints only when already authenticated
        if request.path.startswith('/api/'):
            if not request.session.get('authenticated'):
                return HttpResponseForbidden('Not authenticated.')
            return self.get_response(request)

        # Check session first
        if request.session.get('authenticated'):
            return self.get_response(request)

        # Check token in query string (one-time visit to authenticate)
        supplied = request.GET.get('token', '').strip()
        if supplied and supplied == self.token:
            request.session['authenticated'] = True
            request.session.set_expiry(60 * 60 * 24 * 14)  # 2 weeks
            return self.get_response(request)

        # Not authenticated
        return HttpResponseForbidden(
            '<!DOCTYPE html><html><head><title>Access Denied</title>'
            '<style>body{font-family:sans-serif;display:flex;align-items:center;'
            'justify-content:center;height:100vh;background:#0a0c12;color:#ccd6f6;}'
            '.box{text-align:center;padding:40px;border:1px solid #262c3d;border-radius:12px;}'
            'h1{color:#ff6b9d;font-size:1.5rem;}p{color:#8892b0;margin-top:8px;font-size:.9rem;}'
            '</style></head><body>'
            '<div class="box"><h1>Access Denied</h1>'
            '<p>You need a valid access token to view this dashboard.</p>'
            '<p>Ask your administrator for the dashboard link.</p></div>'
            '</body></html>',
            content_type='text/html',
        )
