"""
stringeex_service.py
All communication with the StringeeX API lives here.

Supports multiple portals — set STRINGEEX_PORTALS=bluewave2,bluewave3 in .env
to fetch from both and merge the results.
"""

import requests
import logging
from datetime import datetime, timedelta, timezone
from django.conf import settings

logger = logging.getLogger(__name__)


class StringeeXError(Exception):
    pass


def _get_portals_list() -> list[str]:
    """
    Returns the list of portals to sync from.
    Reads STRINGEEX_PORTALS (comma-separated) first, falls back to STRINGEEX_PORTAL.
    Example .env:  STRINGEEX_PORTALS=bluewave2,bluewave3
    """
    multi = getattr(settings, 'STRINGEEX_PORTALS', '').strip()
    if multi:
        return [p.strip() for p in multi.split(',') if p.strip()]
    single = getattr(settings, 'STRINGEEX_PORTAL', '').strip()
    if single:
        return [single]
    raise StringeeXError("No portal configured. Set STRINGEEX_PORTALS in .env")


def get_auth_token_for_portal(portal: str) -> tuple[str, str]:
    """
    Authenticate and return (token, base_url) for a specific portal name.
    The API returns domain as plain name (e.g. 'bluewave2'), not full domain.
    """
    # Always login via the portal's own URL
    base_url = f"https://{portal}.stringeex.com"
    url      = f"{base_url}/v1/account"

    payload = {
        "email":    settings.STRINGEEX_EMAIL,
        "password": settings.STRINGEEX_PASSWORD,
    }

    try:
        resp = requests.post(url, json=payload, timeout=15)
        resp.raise_for_status()
    except requests.RequestException as e:
        raise StringeeXError(f"Login failed for portal '{portal}': {e}") from e

    data = resp.json()
    if data.get('r') != 0:
        raise StringeeXError(f"API login error for '{portal}': {data}")

    portals = data.get('portals', [])

    # Match by plain name (e.g. 'bluewave2') — NOT full domain
    token = None
    for p in portals:
        domain = str(p.get('domain', '')).strip()
        if domain == portal:
            token = p.get('auth_token')
            break

    # Fallback: if not matched, try first portal (shouldn't happen with correct name)
    if not token:
        logger.warning(
            "Portal '%s' not found in API response. Available: %s. Using first.",
            portal, [p.get('domain') for p in portals]
        )
        if portals:
            token = portals[0].get('auth_token')

    if not token:
        raise StringeeXError(f"No auth token found for portal '{portal}'")

    logger.info("StringeeX auth OK — portal: %s", portal)
    return token, base_url


def fetch_calls_for_range(token: str, base_url: str,
                          start_dt: datetime, end_dt: datetime,
                          page_size: int = 1000) -> list[dict]:
    """
    Fetch all call records between start_dt and end_dt.
    Handles pagination automatically.
    """
    url     = f"{base_url}/v1/call/history"
    headers = {"X-STRINGEE-AUTH": token, "Content-Type": "application/json"}

    start_ms = int(start_dt.timestamp() * 1000)
    end_ms   = int(end_dt.timestamp() * 1000)

    all_rows = []
    page     = 1

    while True:
        params = {
            "limit":      page_size,
            "page":       page,
            "start_time": start_ms,
            "end_time":   end_ms,
        }

        try:
            resp = requests.get(url, headers=headers, params=params, timeout=20)
            resp.raise_for_status()
        except requests.RequestException as e:
            raise StringeeXError(f"Call history request failed: {e}") from e

        data  = resp.json()
        if data.get('r') != 0:
            raise StringeeXError(f"API error fetching history: {data}")

        rows  = data.get('data', {}).get('rows', [])
        total = data.get('data', {}).get('totalCount', 0)

        all_rows.extend(rows)
        logger.info("Page %d — fetched %d / %d records", page, len(all_rows), total)

        if len(all_rows) >= total or not rows:
            break

        page += 1

    return all_rows


def fetch_all_portals_for_range(start_dt: datetime, end_dt: datetime) -> list[dict]:
    """
    Fetch call records from ALL configured portals and merge results.
    Each record is tagged with its source portal name.
    Deduplication by 'id' is handled at upsert time.
    """
    portals   = _get_portals_list()
    all_rows  = []

    for portal in portals:
        logger.info("Fetching from portal: %s", portal)
        try:
            token, base_url = get_auth_token_for_portal(portal)
            rows = fetch_calls_for_range(token, base_url, start_dt, end_dt)
            # Tag each row with portal so logs are clear
            for r in rows:
                r['_portal'] = portal
            all_rows.extend(rows)
            logger.info("Portal %s — %d records fetched", portal, len(rows))
        except StringeeXError as e:
            logger.error("Failed to fetch from portal '%s': %s", portal, e)
            # Continue with other portals even if one fails

    return all_rows


# Legacy single-portal helpers (kept for compatibility)
def get_auth_token() -> tuple[str, str]:
    portals = _get_portals_list()
    return get_auth_token_for_portal(portals[0])
