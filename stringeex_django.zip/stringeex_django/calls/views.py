import json
from datetime import datetime, timezone, timedelta

from django.shortcuts import render
from django.http import JsonResponse
from django.db.models import Avg, Count, Sum, Q
from django.views.decorators.http import require_GET

from .models import CallRecord


# ── Main Dashboard ─────────────────────────────────────────────────────────────

def dashboard(request):
    return render(request, 'calls/dashboard.html')


# ── API: KPI Stats ─────────────────────────────────────────────────────────────

@require_GET
def api_stats(request):
    """
    Overall KPI stats.
    Query params:
      ?days=7       — filter last N days (default: all time)
      ?agent=email  — filter by account_name (agent email)
      ?tl=name      — filter by TL name
    """
    days  = request.GET.get('days')
    agent = request.GET.get('agent', '').strip()
    tl    = request.GET.get('tl', '').strip()

    qs = CallRecord.objects.all()

    if days:
        try:
            cutoff_ms = int(
                (datetime.now(tz=timezone.utc) - timedelta(days=int(days))).timestamp() * 1000
            )
            qs = qs.filter(start_time_ms__gte=cutoff_ms)
        except (ValueError, TypeError):
            pass

    if agent:
        qs = qs.filter(account_name__iexact=agent)

    if tl:
        qs = qs.filter(tl__iexact=tl)

    agg = qs.aggregate(
        total=Count('id'),
        avg_talk=Avg('talk_duration'),
        total_talk=Sum('talk_duration'),
        total_duration=Sum('duration'),
        connected=Count('id', filter=Q(talk_duration__gt=0)),
        inbound=Count('id', filter=Q(direction='inbound')),
        outbound=Count('id', filter=Q(direction='outbound')),
    )

    total        = agg['total'] or 0
    connected    = agg['connected'] or 0
    connect_rate = round(connected / total * 100, 1) if total else 0

    return JsonResponse({
        'total':            total,
        'connected':        connected,
        'connect_rate':     connect_rate,
        'inbound':          agg['inbound'] or 0,
        'outbound':         agg['outbound'] or 0,
        'avg_talk_secs':    round(agg['avg_talk'] or 0),
        'total_talk_mins':  round((agg['total_talk'] or 0) / 60),
        'total_dur_mins':   round((agg['total_duration'] or 0) / 60),
    })


# ── API: Call Records Table ────────────────────────────────────────────────────

@require_GET
def api_calls(request):
    """
    Paginated call records as JSON.
    Query params:
      ?limit=50 &offset=0
      ?direction=inbound|outbound
      ?search=<customer number or agent name>
      ?agent=<account_name email>
      ?tl=<TL name>
      ?connected=1     — only answered calls
    """
    limit     = min(int(request.GET.get('limit', 50)), 500)
    offset    = int(request.GET.get('offset', 0))
    direction = request.GET.get('direction', '')
    search    = request.GET.get('search', '').strip()
    agent     = request.GET.get('agent', '').strip()
    tl        = request.GET.get('tl', '').strip()
    connected = request.GET.get('connected', '')

    qs = CallRecord.objects.all()

    if direction in ('inbound', 'outbound', 'internal'):
        qs = qs.filter(direction=direction)

    if agent:
        qs = qs.filter(account_name__iexact=agent)

    if tl:
        qs = qs.filter(tl__iexact=tl)

    if connected == '1':
        qs = qs.filter(talk_duration__gt=0)

    if search:
        qs = qs.filter(
            Q(customer_number__icontains=search) |
            Q(account_name__icontains=search)    |
            Q(full_name__icontains=search)
        )

    total = qs.count()
    rows  = qs[offset: offset + limit]

    data = []
    for r in rows:
        data.append({
            'id':                    r.id,
            'account_name':          r.account_name or '—',
            'full_name':             r.full_name or r.account_name or '—',
            'employee_code':         r.employee_code or '—',
            'pool':                  r.pool or '—',
            'tl':                    r.tl or '—',
            'vertical':              r.vertical or '—',
            'direction':             r.direction or '—',
            'start_time_ms':         r.start_time_ms,
            'duration':              r.duration,
            'talk_duration':         r.talk_duration,
            'answer_duration':       r.answer_duration,
            'queue_duration_secs':   r.queue_duration_secs,
            # Formatted HH:MM:SS strings (mirrors notebook output)
            'talk_duration_display':  r.talk_duration_display,
            'queue_duration_display': r.queue_duration_display,
            'total_duration_display': r.total_duration_display,
            'duration_display':       r.duration_display,
            'end_call_reason':        r.end_call_reason or '—',
            'customer_number':        r.customer_number or '—',
            'stringee_number':        r.stringee_number or '—',
            'is_connected':           r.is_connected,
        })

    return JsonResponse({'total': total, 'rows': data})


# ── API: Agent Summary (new — replaces raw notebook aggregation) ───────────────

@require_GET
def api_agent_summary(request):
    """
    Per-agent summary for the Stringee dialer report.
    Returns one row per agent with: total calls, connected, talk time, queue time.
    Query params: ?days=N, ?tl=name
    """
    from django.db.models import IntegerField
    from django.db.models.functions import Coalesce

    days = request.GET.get('days')
    tl   = request.GET.get('tl', '').strip()

    qs = CallRecord.objects.all()

    if days:
        try:
            cutoff_ms = int(
                (datetime.now(tz=timezone.utc) - timedelta(days=int(days))).timestamp() * 1000
            )
            qs = qs.filter(start_time_ms__gte=cutoff_ms)
        except (ValueError, TypeError):
            pass

    if tl:
        qs = qs.filter(tl__iexact=tl)

    agents = (
        qs.values('account_name', 'full_name', 'employee_code', 'pool', 'tl', 'vertical')
        .annotate(
            total_calls=Count('id'),
            connected_calls=Count('id', filter=Q(talk_duration__gt=0)),
            total_talk_secs=Sum('talk_duration'),
            total_duration_secs=Sum('duration'),
        )
        .order_by('-total_calls')
    )

    rows = []
    for a in agents:
        total        = a['total_calls'] or 0
        connected    = a['connected_calls'] or 0
        talk_secs    = a['total_talk_secs'] or 0
        dur_secs     = a['total_duration_secs'] or 0
        queue_secs   = max(dur_secs - talk_secs, 0)

        rows.append({
            'account_name':    a['account_name'] or '—',
            'full_name':       a['full_name'] or a['account_name'] or '—',
            'employee_code':   a['employee_code'] or '—',
            'pool':            a['pool'] or '—',
            'tl':              a['tl'] or '—',
            'vertical':        a['vertical'] or '—',
            'total_calls':     total,
            'connected_calls': connected,
            'connect_rate':    round(connected / total * 100, 1) if total else 0,
            'talk_time':       _secs_to_hhmmss(talk_secs),
            'queue_time':      _secs_to_hhmmss(queue_secs),
            'total_time':      _secs_to_hhmmss(dur_secs),
        })

    return JsonResponse({'rows': rows})


# ── API: Chart — calls per day ─────────────────────────────────────────────────

@require_GET
def api_chart_daily(request):
    cutoff_ms = int(
        (datetime.now(tz=timezone.utc) - timedelta(days=30)).timestamp() * 1000
    )
    records = (
        CallRecord.objects
        .filter(start_time_ms__gte=cutoff_ms)
        .values_list('start_time_ms', 'direction', 'talk_duration')
    )

    day_totals    = {}
    day_connected = {}
    day_inbound   = {}
    day_outbound  = {}

    for ms, direction, talk in records:
        if not ms:
            continue
        day = datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime('%Y-%m-%d')
        day_totals[day]    = day_totals.get(day, 0) + 1
        if (talk or 0) > 0:
            day_connected[day] = day_connected.get(day, 0) + 1
        if direction == 'inbound':
            day_inbound[day]   = day_inbound.get(day, 0) + 1
        elif direction == 'outbound':
            day_outbound[day]  = day_outbound.get(day, 0) + 1

    labels, totals, connected, inbounds, outbounds = [], [], [], [], []
    for i in range(29, -1, -1):
        day = (datetime.now(tz=timezone.utc) - timedelta(days=i)).strftime('%Y-%m-%d')
        labels.append(day)
        totals.append(day_totals.get(day, 0))
        connected.append(day_connected.get(day, 0))
        inbounds.append(day_inbound.get(day, 0))
        outbounds.append(day_outbound.get(day, 0))

    return JsonResponse({
        'labels':    labels,
        'totals':    totals,
        'connected': connected,
        'inbound':   inbounds,
        'outbound':  outbounds,
    })


# ── API: Last Sync ─────────────────────────────────────────────────────────────

@require_GET
def api_last_sync(request):
    latest = CallRecord.objects.order_by('-fetched_at').values('fetched_at').first()
    if latest:
        return JsonResponse({'last_sync': latest['fetched_at'].isoformat()})
    return JsonResponse({'last_sync': None})


# ── helpers ────────────────────────────────────────────────────────────────────

def _secs_to_hhmmss(secs: int) -> str:
    secs = int(secs or 0)
    h, rem = divmod(secs, 3600)
    m, s   = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"
