import json
from datetime import datetime, timezone, timedelta
from collections import defaultdict
from zoneinfo import ZoneInfo

from django.shortcuts import render
from django.http import JsonResponse
from django.db.models import Avg, Count, Sum, Q
from django.views.decorators.http import require_GET

from .models import CallRecord
from .team_lookup import get_team_lookup, enrich_record, all_excel_agents

# IST is UTC+5:30 — ALL date boundaries and hour labels must use this
LOCAL_TZ = ZoneInfo('Asia/Kolkata')


def dashboard(request):
    return render(request, 'calls/dashboard.html')


def _day_ms_range(date_str: str) -> tuple[int, int]:
    """
    Return (day_start_ms, day_end_ms) covering midnight–23:59:59 in Dubai time.
    The DB stores raw UTC milliseconds from the API, so we convert Dubai midnight
    to UTC ms before querying.
    """
    try:
        td = datetime.strptime(date_str, '%Y-%m-%d')
    except (ValueError, TypeError):
        td = datetime.now(tz=LOCAL_TZ)

    day_start = datetime(td.year, td.month, td.day,  0,  0,  0, tzinfo=LOCAL_TZ)
    day_end   = datetime(td.year, td.month, td.day, 23, 59, 59, tzinfo=LOCAL_TZ)
    return int(day_start.timestamp() * 1000), int(day_end.timestamp() * 1000)


def _ms_to_local_hour(ms: int | None) -> int:
    """Convert a UTC-millisecond timestamp to the Dubai local hour (0-23)."""
    if not ms:
        return 0
    return datetime.fromtimestamp(ms / 1000, tz=LOCAL_TZ).hour


@require_GET
def api_stats(request):
    date_str = request.GET.get('date', '').strip()
    days     = request.GET.get('days')
    agent    = request.GET.get('agent', '').strip()
    tl       = request.GET.get('tl', '').strip()

    qs = CallRecord.objects.all()

    if date_str:
        s, e = _day_ms_range(date_str)
        qs = qs.filter(start_time_ms__gte=s, start_time_ms__lte=e)
    elif days:
        try:
            cutoff_ms = int((datetime.now(tz=LOCAL_TZ) - timedelta(days=int(days))).timestamp() * 1000)
            qs = qs.filter(start_time_ms__gte=cutoff_ms)
        except (ValueError, TypeError):
            pass

    if agent:
        qs = qs.filter(account_name__iexact=agent)
    if tl:
        qs = qs.filter(tl__iexact=tl)

    agg = qs.aggregate(
        total=Count('id'),
        avg_talk=Avg('talk_duration'),
        total_talk=Sum('talk_duration'),
        total_duration=Sum('duration'),
        connected=Count('id', filter=Q(talk_duration__gt=0)),
        inbound=Count('id', filter=Q(direction='inbound')),
        outbound=Count('id', filter=Q(direction='outbound')),
    )
    total     = agg['total'] or 0
    connected = agg['connected'] or 0
    return JsonResponse({
        'total':           total,
        'connected':       connected,
        'connect_rate':    round(connected / total * 100, 1) if total else 0,
        'inbound':         agg['inbound'] or 0,
        'outbound':        agg['outbound'] or 0,
        'avg_talk_secs':   round(agg['avg_talk'] or 0),
        'total_talk_mins': round((agg['total_talk'] or 0) / 60),
        'total_dur_mins':  round((agg['total_duration'] or 0) / 60),
    })


@require_GET
def api_hourly_breakdown(request):
    tl       = request.GET.get('tl', '').strip()
    pool     = request.GET.get('pool', '').strip()
    agent    = request.GET.get('agent', '').strip()
    date_str = request.GET.get('date', '').strip()

    day_start_ms, day_end_ms = _day_ms_range(date_str)

    try:
        td = datetime.strptime(date_str, '%Y-%m-%d') if date_str else datetime.now(tz=LOCAL_TZ)
    except ValueError:
        td = datetime.now(tz=LOCAL_TZ)

    qs = CallRecord.objects.filter(
        start_time_ms__gte=day_start_ms,
        start_time_ms__lte=day_end_ms,
    ).exclude(end_call_reason__in=['404 Not Found', 'CAN_NOT_MAKE_CALL'])

    if tl:
        qs = qs.filter(tl__iexact=tl)
    if pool:
        qs = qs.filter(pool__iexact=pool)
    if agent:
        qs = qs.filter(account_name__iexact=agent)

    records = qs.values(
        'account_name', 'full_name', 'employee_code', 'pool', 'tl', 'vertical',
        'start_time_ms', 'customer_number', 'duration', 'talk_duration',
    )

    agent_hour_data: dict = defaultdict(lambda: defaultdict(lambda: {
        'calls': 0, 'customers': set(), 'duration': 0, 'talk_duration': 0
    }))
    agent_meta: dict = {}

    for r in records:
        acc = r['account_name'] or 'Unknown'
        if acc not in agent_meta:
            agent_meta[acc] = {
                'full_name':     r['full_name'] or acc,
                'employee_code': r['employee_code'] or '—',
                'pool':          r['pool'] or '—',
                'tl':            r['tl'] or '—',
                'vertical':      r['vertical'] or '—',
            }
        # ← KEY FIX: bucket by Dubai local hour, not UTC hour
        hour = _ms_to_local_hour(r['start_time_ms'])
        b = agent_hour_data[acc][hour]
        b['calls'] += 1
        if r['customer_number']:
            b['customers'].add(r['customer_number'])
        b['duration']      += r['duration'] or 0
        b['talk_duration'] += r['talk_duration'] or 0

    all_hours: set = set()
    for acc_data in agent_hour_data.values():
        all_hours.update(acc_data.keys())
    sorted_hours = sorted(all_hours)

    rows = []
    grand_totals: dict = defaultdict(lambda: {
        'calls': 0, 'unique_dials': 0, 'duration': 0, 'talk_duration': 0
    })

    for acc, meta in sorted(agent_meta.items(), key=lambda x: x[0].lower()):
        hourly      = {}
        agent_total = {'calls': 0, 'unique_dials': 0, 'duration': 0, 'talk_duration': 0}
        for h in sorted_hours:
            b     = agent_hour_data[acc].get(h, {})
            calls = b.get('calls', 0)
            custs = b.get('customers', set())
            dur   = b.get('duration', 0)
            talk  = b.get('talk_duration', 0)
            hourly[h] = {
                'calls': calls, 'unique_dials': len(custs),
                'duration': dur, 'talk_duration': talk,
            }
            agent_total['calls']         += calls
            agent_total['unique_dials']  += len(custs)
            agent_total['duration']      += dur
            agent_total['talk_duration'] += talk
            grand_totals[h]['calls']         += calls
            grand_totals[h]['unique_dials']  += len(custs)
            grand_totals[h]['duration']      += dur
            grand_totals[h]['talk_duration'] += talk
        rows.append({
            'account_name':  acc,
            'full_name':     meta['full_name'],
            'employee_code': meta['employee_code'],
            'pool':          meta['pool'],
            'tl':            meta['tl'],
            'vertical':      meta['vertical'],
            'hourly':        hourly,
            'totals':        agent_total,
        })

    hour_totals = {h: grand_totals[h] for h in sorted_hours}
    return JsonResponse({
        'hours':       sorted_hours,
        'rows':        rows,
        'hour_totals': hour_totals,
        'date':        td.strftime('%Y-%m-%d'),
    })


@require_GET
def api_team_list(request):
    """
    Returns all agents, TLs, and pools for the sidebar and filter dropdowns.

    Sources merged in priority order:
      1. Team_tradex.xlsx (source of truth — always current)
      2. DB CallRecords (catches agents who made calls but aren't in the Excel yet)

    Matching is prefix-based: 'anushka@bluewave.com' matches 'anushka@nexora.live'
    because both share prefix 'anushka'.
    """
    # ── Source 1: Excel ──────────────────────────────────────────────────────
    excel_agents = all_excel_agents()   # list of {account_name(prefix), full_name, tl, pool, ...}
    by_prefix: dict = {ag['account_name']: ag for ag in excel_agents}

    # ── Source 2: DB — agents with actual calls (use their real API email) ───
    db_agents = list(
        CallRecord.objects
        .exclude(account_name__isnull=True).exclude(account_name='')
        .values('account_name', 'full_name', 'tl', 'pool')
        .distinct()
    )
    for a in db_agents:
        acc    = (a['account_name'] or '').strip()
        prefix = acc.split('@')[0].lower()
        if not prefix:
            continue
        if prefix in by_prefix:
            # Excel has this agent — update account_name to the real API email
            by_prefix[prefix]['account_name'] = acc
        else:
            # Not in Excel — add from DB with whatever metadata was synced
            by_prefix[prefix] = {
                'account_name':  acc,
                'full_name':     a.get('full_name') or acc,
                'tl':            a.get('tl') or '',
                'pool':          a.get('pool') or '',
                'employee_code': '',
                'vertical':      '',
            }

    merged = sorted(
        by_prefix.values(),
        key=lambda a: (a.get('full_name') or a.get('account_name') or '').lower()
    )

    # Build TL and Pool lists from the merged set
    tls   = sorted({a['tl']   for a in merged if a.get('tl')},   key=str.lower)
    pools = sorted({a['pool'] for a in merged if a.get('pool')}, key=str.lower)

    return JsonResponse({'tls': tls, 'pools': pools, 'agents': merged})


@require_GET
def api_calls(request):
    limit     = min(int(request.GET.get('limit', 50)), 500)
    offset    = int(request.GET.get('offset', 0))
    direction = request.GET.get('direction', '')
    search    = request.GET.get('search', '').strip()
    agent     = request.GET.get('agent', '').strip()
    tl        = request.GET.get('tl', '').strip()
    connected = request.GET.get('connected', '')
    date_str  = request.GET.get('date', '').strip()

    qs = CallRecord.objects.all()

    if date_str:
        s, e = _day_ms_range(date_str)
        qs = qs.filter(start_time_ms__gte=s, start_time_ms__lte=e)

    if direction in ('inbound', 'outbound', 'internal'):
        qs = qs.filter(direction=direction)
    if agent:
        qs = qs.filter(account_name__iexact=agent)
    if tl:
        qs = qs.filter(tl__iexact=tl)
    if connected == '1':
        qs = qs.filter(talk_duration__gt=0)
    if search:
        qs = qs.filter(
            Q(customer_number__icontains=search) |
            Q(account_name__icontains=search)    |
            Q(full_name__icontains=search)
        )

    total = qs.count()
    rows  = qs[offset: offset + limit]
    data  = []
    for r in rows:
        data.append({
            'id':                    r.id,
            'account_name':          r.account_name or '—',
            'full_name':             r.full_name or r.account_name or '—',
            'employee_code':         r.employee_code or '—',
            'pool':                  r.pool or '—',
            'tl':                    r.tl or '—',
            'vertical':              r.vertical or '—',
            'direction':             r.direction or '—',
            'start_time_ms':         r.start_time_ms,
            'end_time_ms':           r.end_time_ms,
            'duration':              r.duration,
            'talk_duration':         r.talk_duration,
            'answer_duration':       r.answer_duration,
            'queue_duration_secs':   r.queue_duration_secs,
            'talk_duration_display':  r.talk_duration_display,
            'queue_duration_display': r.queue_duration_display,
            'total_duration_display': r.total_duration_display,
            'duration_display':      r.duration_display,
            'end_call_reason':       r.end_call_reason or '—',
            'customer_number':       r.customer_number or '—',
            'stringee_number':       r.stringee_number or '—',
            'is_connected':          r.is_connected,
        })
    return JsonResponse({'total': total, 'rows': data})


@require_GET
def api_agent_summary(request):
    date_str = request.GET.get('date', '').strip()
    days     = request.GET.get('days')
    tl       = request.GET.get('tl', '').strip()

    qs = CallRecord.objects.all()

    if date_str:
        s, e = _day_ms_range(date_str)
        qs = qs.filter(start_time_ms__gte=s, start_time_ms__lte=e)
    elif days:
        try:
            cutoff_ms = int((datetime.now(tz=LOCAL_TZ) - timedelta(days=int(days))).timestamp() * 1000)
            qs = qs.filter(start_time_ms__gte=cutoff_ms)
        except (ValueError, TypeError):
            pass

    if tl:
        qs = qs.filter(tl__iexact=tl)

    agents = (
        qs.values('account_name', 'full_name', 'employee_code', 'pool', 'tl', 'vertical')
        .annotate(
            total_calls=Count('id'),
            connected_calls=Count('id', filter=Q(talk_duration__gt=0)),
            total_talk_secs=Sum('talk_duration'),
            total_duration_secs=Sum('duration'),
        )
        .order_by('-total_calls')
    )

    rows = []
    for a in agents:
        total     = a['total_calls'] or 0
        connected = a['connected_calls'] or 0
        talk_secs = a['total_talk_secs'] or 0
        dur_secs  = a['total_duration_secs'] or 0
        rows.append({
            'account_name':    a['account_name'] or '—',
            'full_name':       a['full_name'] or a['account_name'] or '—',
            'employee_code':   a['employee_code'] or '—',
            'pool':            a['pool'] or '—',
            'tl':              a['tl'] or '—',
            'vertical':        a['vertical'] or '—',
            'total_calls':     total,
            'connected_calls': connected,
            'connect_rate':    round(connected / total * 100, 1) if total else 0,
            'talk_time':       _secs_to_hhmmss(talk_secs),
            'queue_time':      _secs_to_hhmmss(max(dur_secs - talk_secs, 0)),
            'total_time':      _secs_to_hhmmss(dur_secs),
        })
    return JsonResponse({'rows': rows})


@require_GET
def api_last_sync(request):
    latest = CallRecord.objects.order_by('-fetched_at').values('fetched_at').first()
    if latest:
        return JsonResponse({'last_sync': latest['fetched_at'].isoformat()})
    return JsonResponse({'last_sync': None})


@require_GET
def api_reload_team(request):
    """
    Force-reload Team_tradex.xlsx without restarting the server.
    Hit GET /api/reload-team/ after updating the xlsx.
    """
    from .team_lookup import reload_team_lookup
    lookup = reload_team_lookup()
    return JsonResponse({'status': 'ok', 'agents_loaded': len(lookup)})


def _secs_to_hhmmss(secs: int) -> str:
    secs = int(secs or 0)
    h, rem = divmod(secs, 3600)
    m, s   = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"
