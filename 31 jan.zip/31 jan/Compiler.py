import os
import glob
import pandas as pd
import requests
from datetime import datetime


INPUT_PATH = r"C:\Users\Akhil\Desktop\scrap"
FOLDER_PATH = r"C:\Users\Akhil\Documents\result"

WEBHOOK_URL = (
    "https://flow.zoho.com/888014017/flow/webhook/incoming"
    "?zapikey=1001.5e8c4caa107e92ebac011c68094d7f85.06f7a3dab157dfe4afd438402335a6a5"
    "&isdebug=false"
)

COLUMN_MAPPING = {
    "phoneNumber": "number",
    "Lead Source 2": "source",
    "Account Id": "name",
    "Username": "username",
    "Website Name": "website"
}


def main():
    # ===============================
    # LOAD INPUT CSVs
    # ===============================
    all_files = os.listdir(INPUT_PATH)
    full_data = pd.DataFrame()

    for file in all_files:
        if file.endswith(".csv"):
            df = pd.read_csv(os.path.join(INPUT_PATH, file))
            full_data = pd.concat([full_data, df], ignore_index=True)

    # ===============================
    # DATE FILTER
    # ===============================
    if "Created Time" in full_data.columns:
        full_data["Date"] = full_data["Created Time"].str.split(",").str[0]
        full_data["Date"] = pd.to_datetime(
            full_data["Date"], format="%d/%m/%Y", errors="coerce"
        )
        full_data = full_data.dropna(subset=["Date"])

        yesterday = pd.Timestamp.today().normalize() - pd.Timedelta(days=1)
        full_data = full_data[full_data["Date"] >= yesterday]

    # ===============================
    # COLUMN MAPPING
    # ===============================
    full_data = full_data[list(COLUMN_MAPPING.keys())].rename(columns=COLUMN_MAPPING)
    full_data["key"] = full_data["number"].astype(str) + full_data["source"].astype(str)

    full_data_push = full_data[["number", "source", "name", "username", "website"]]

    # ===============================
    # LOAD LATEST BACKUP CSV
    # ===============================
    csv_files = glob.glob(os.path.join(FOLDER_PATH, "*.csv"))

    if not csv_files:
        print("⚠️ No backup CSV found. Skipping comparison.")
        df_json = pd.DataFrame(columns=["number", "source", "key"])
    else:
        latest_file = max(csv_files, key=os.path.getmtime)
        df_json = pd.read_csv(latest_file)
        print("📄 Latest file loaded:", latest_file)

        df_json["number"] = df_json["number"].astype(str)
        df_json["source"] = df_json["source"].astype(str)
        df_json["key"] = df_json["number"] + df_json["source"]

        df_json["number"] = df_json["number"].apply(
            lambda x: x if x.startswith("+") else "+" + x
        )

    # ===============================
    # FIND NEW LEADS
    # ===============================
    wbhook_push = pd.merge(full_data, df_json, on="key", how="left")
    wbhook_push = wbhook_push[wbhook_push["name_y"].isnull()]
    wbhook_push = wbhook_push[
        ["number_x", "source_x", "name_x", "username_x", "website_x"]]
    # --- FIX PHONE NUMBER PROPERLY ---
    wbhook_push["number_x"] = (wbhook_push["number_x"]
    .astype(str)
    .str.replace(r"\.0$", "", regex=True)
    .str.strip()
)

    # ===============================
    # SAVE JSON OUTPUT
    # ===============================
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(FOLDER_PATH, f"processed_leads_{timestamp}.json")
    full_data.to_json(
        output_file, orient="records", force_ascii=False, date_format="iso"
    )
    print(f"💾 Saved processed leads to: {output_file}")

    # ===============================
    # PUSH TO ZOHO FLOW
    # ===============================
    if wbhook_push.empty:
        print("✅ No new leads to push.")
    else:
        headers = {"Content-Type": "application/json"}

        for index, row in wbhook_push.iterrows():
            try:
                number = str(row["number_x"]).strip()
                if not number.startswith("+"):
                    number = "+" + number

                payload = {
                    "number": number,
                    "name": str(row["name_x"]).strip(),
                    "source": str(row["source_x"]).strip(),
                    "username": str(row["username_x"]).strip(),
                    "website": str(row["website_x"]).strip()
                }

                response = requests.post(
                    WEBHOOK_URL,
                    json=payload,
                    headers=headers,
                    timeout=10,
                )

                if response.status_code == 200:
                    print(f"✅ Sent ({index + 1}/{len(wbhook_push)}): {number}")
                else:
                    print(
                        f"❌ Failed ({index + 1}/{len(wbhook_push)}): {number} | "
                        f"Status: {response.status_code} | {response.text}"
                    )

            except requests.exceptions.RequestException as e:
                print(f"🚨 Exception for {row['number_x']}: {e}")

        print("🎯 All new leads have been processed.")

    # ===============================
    # SAVE BACKUP CSV
    # ===============================
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_file = os.path.join(
        FOLDER_PATH, f"full_data_push_before_wbhook_{timestamp}.csv"
    )

    full_data_push.to_csv(backup_file, index=False)
    print(f"📦 Backup saved: {backup_file}")


if __name__ == "__main__":
    main()
