from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def main():
    options = webdriver.ChromeOptions()
    # Add any desired Chrome options here, e.g. headless, disable-gpu, etc.
    # options.add_argument("--headless")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )

    try:
        ### **Login Page** ###
        driver.get("http://192.168.8.1/#/login")
        time.sleep(3)

        driver.find_element(By.CSS_SELECTOR,
            'input[placeholder="Please enter your user name"]').send_keys("user")

        driver.find_element(By.CSS_SELECTOR,
            'input[placeholder="Please enter your password"]').send_keys("Qwerty@5429")

        driver.find_element(By.XPATH,
            "//button[contains(.,'Log In')]").click()

        ### **Advance Menu**
        wait = WebDriverWait(driver, 20)

        advanced_menu = wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, '//*[@id="first_menu_advanceset"]/div')
            )
        )

        advanced_menu.click()
        print("✅ Advanced menu clicked")

        ### **Clicking System Menu** ###

        # wait object
        wait = WebDriverWait(driver, 20)

        # wait until System menu is clickable
        system_menu = wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, '//*[@id="left_menu_system"]')
            )
        )

        # click System
        system_menu.click()
        print("✅ System menu clicked")

        ### **Clicking Reboot Menu** ###

        # wait object (adjust driver variable as needed)
        wait = WebDriverWait(driver, 20)

        # wait until Reboot menu/button is clickable
        reboot_menu = wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, '//*[@id="left_menu_reboot"]')
            )
        )

        # click Reboot
        reboot_menu.click()
        print("✅ Reboot menu clicked")

        ### **Clicking Restart Button And Confirmation button**

        # Create a wait object (assuming 'driver' is your Selenium WebDriver)
        wait = WebDriverWait(driver, 20)

        # Step 1: Click the Reboot button
        reboot_button = wait.until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="rebootBtn"]'))
        )
        reboot_button.click()
        print("✅ Reboot button clicked")

        # Step 2: Click the confirmation button
        confirm_button = wait.until(
            EC.element_to_be_clickable((By.XPATH, '//*[@id="rebootConfirmlBtn"]/span'))
        )
        confirm_button.click()
        print("✅ Reboot confirmed")

        # wait for 3 minutes to allow reboot to complete
        time.sleep(130)
    finally:
        driver.quit()

if __name__ == "__main__":
    main()
