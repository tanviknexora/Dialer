import time
import random
import pandas as pd
from io import StringIO
from bs4 import BeautifulSoup

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    NoSuchElementException,
    StaleElementReferenceException,
)

import undetected_chromedriver as uc
from selenium_stealth import stealth
from fake_useragent import UserAgent


# ------------------ Human Delay ------------------
def human_delay(min_seconds=2, max_seconds=5):
    time.sleep(random.uniform(min_seconds, max_seconds))


# ------------------ Driver Setup ------------------
def get_driver():
    options = uc.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-blink-features=AutomationControlled")

    driver = uc.Chrome(version_main=144, options=options)

    stealth(
        driver,
        languages=["en-US", "en"],
        vendor="Google Inc.",
        platform="Win32",
        webgl_vendor="Intel Inc.",
        renderer="Intel Iris OpenGL",
        fix_hairline=True,
    )
    return driver


# ------------------ Main Script ------------------
def main():
    driver = get_driver()
    wait = WebDriverWait(driver, 15)

    # Access website
    driver.get("https://affiliate.winfix.fun/login")

    # Login
    human_delay()
    driver.find_element(
        By.XPATH, '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input'
    ).send_keys("winfix_bh")

    human_delay()
    driver.find_element(
        By.XPATH, '//*[@id="standard-adornment-password"]'
    ).send_keys("tUWWsxK8w1Tv2")

    human_delay()
    driver.find_element(
        By.XPATH, '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]'
    ).click()

    # User Management
    human_delay()
    user_mgmt = wait.until(
        EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="root"]/ion-app/div[3]/ion-toolbar/div/div/ion-header/div/a[2]/span/span[1]')
        )
    )
    driver.execute_script("arguments[0].click();", user_mgmt)

    # Affiliate
    human_delay()
    affiliate_btn = wait.until(
        EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="root"]/ion-app/ion-content/div/div/div[2]/div[2]/div')
        )
    )
    driver.execute_script("arguments[0].click();", affiliate_btn)

    # Click specific user row (last one used)
    human_delay()
    u_button = wait.until(
        EC.element_to_be_clickable(
            (By.XPATH, '//*[@id="root"]/ion-app/ion-content/div/div/div[3]/div[1]/table/tbody/tr[5]/td[6]/button[3]')
        )
    )
    driver.execute_script("arguments[0].click();", u_button)

    # ------------------ Pagination Scraping ------------------
    table_xpath = '//*[@id="root"]/ion-app/ion-content/div/div/div[3]/div[1]/table'
    next_button_xpath = "//button[contains(@class,'aum-prev-next-btn')]//span[contains(text(),'next')]"

    df_all = pd.DataFrame()

    while True:
        try:
            table = wait.until(EC.presence_of_element_located((By.XPATH, table_xpath)))
            soup = BeautifulSoup(table.get_attribute("outerHTML"), "html.parser")
            df_page = pd.read_html(StringIO(str(soup)))[0]
            df_all = pd.concat([df_all, df_page], ignore_index=True)

            prev_first_cell = df_page.iloc[0, 0]

            next_button = driver.find_element(By.XPATH, next_button_xpath)
            if not next_button.is_enabled():
                break

            driver.execute_script("arguments[0].click();", next_button)

            def table_updated(drv):
                new_table = drv.find_element(By.XPATH, table_xpath)
                new_df = pd.read_html(
                    StringIO(new_table.get_attribute("outerHTML"))
                )[0]
                return new_df.iloc[0, 0] != prev_first_cell

            wait.until(table_updated)
            time.sleep(random.uniform(1, 3))

        except (TimeoutException, NoSuchElementException):
            break
        except StaleElementReferenceException:
            time.sleep(2)
            continue

    # ------------------ Data Processing ------------------
    df_final = df_all.copy()
    df_final["language"] = "Hindi"
    df_final["Website Name"] = "winfix.fun"
    df_final["Account Id"] = df_final["Username"]
    df_final["Lead Source 2"] = "Black Hat - Meta"

    df_final = df_final[
        (df_final[["Available Bal", "Points W/L", "Exposure", "Lifetime Profit"]] == 0).all(axis=1)
    ]

    df_final = df_final[
        ["phoneNumber", "Username", "Lead Source 2", "language",
         "Website Name", "Account Id", "Created Time"]
    ]

    df_final["Username"] = df_final["Username"].str[:-4]
    df_final["Account Id"] = df_final["Account Id"].str[:-4]

    df_final.to_csv(
        r"C:\Users\Akhil\Desktop\scrap\black_Hat4.csv",
        index=False
    )

    driver.quit()
    print("Scraping completed successfully.")


# ------------------ Entry Point ------------------
if __name__ == "__main__":
    main()
