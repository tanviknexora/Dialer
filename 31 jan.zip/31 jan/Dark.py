import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from fake_useragent import UserAgent
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    StaleElementReferenceException,
    NoSuchElementException,
)
import pandas as pd
import time
import datetime
from io import StringIO
import random
import undetected_chromedriver as uc
from selenium_stealth import stealth
from bs4 import BeautifulSoup
import re


# Human-like delay
def human_delay(a: float = 1, b: float = 3) -> None:
    """Sleep for a random time between a and b seconds."""
    time.sleep(random.uniform(a, b))


def get_driver():
    ua = UserAgent()

    chrome_options = uc.ChromeOptions()
    chrome_options.add_argument(f'--user-agent={ua.random}')
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-gpu")

    # Adjust version_main to your Chrome version
    driver = uc.Chrome(version_main=144, options=chrome_options)

    stealth(
        driver,
        languages=["en-US", "en"],
        vendor="Google Inc.",
        platform="Win32",
        webgl_vendor="Intel Inc.",
        renderer="Intel Iris OpenGL",
        fix_hairline=True,
    )

    return driver


def main():
    driver = get_driver()
    wait = WebDriverWait(driver, 15)

    try:
        # Accessing the Website
        website = "https://affiliate.winfix.fun/login"
        driver.get(website)

        # Login
        human_delay()
        username_box = driver.find_element(
            By.XPATH,
            '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input',
        )
        username_box.send_keys("Winfix_DA")

        human_delay()
        password_box = driver.find_element(
            By.XPATH,
            '//*[@id="standard-adornment-password"]',
        )
        password_box.send_keys("1XXd9VNxemGp2")

        human_delay()
        login_button = driver.find_element(
            By.XPATH,
            '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]',
        )
        login_button.click()

        # User Management
        human_delay()
        user_mgmt_button = wait.until(
            EC.element_to_be_clickable(
                (
                    By.XPATH,
                    '//*[@id="root"]/ion-app/div[3]/ion-toolbar/div/div/ion-header/div/a[2]/span/span[1]',
                )
            )
        )
        driver.execute_script("arguments[0].click();", user_mgmt_button)

        # Affiliate
        human_delay()
        affiliate_button = wait.until(
            EC.element_to_be_clickable(
                (
                    By.XPATH,
                    '//*[@id="root"]/ion-app/ion-content/div/div/div[2]/div[2]/div',
                )
            )
        )
        driver.execute_script("arguments[0].scrollIntoView();", affiliate_button)
        driver.execute_script("arguments[0].click();", affiliate_button)

        # U button (first row)
        human_delay()
        u_button = wait.until(
            EC.element_to_be_clickable(
                (
                    By.XPATH,
                    '//*[@id="root"]/ion-app/ion-content/div/div/div[3]/div[1]/table/tbody/tr/td[6]/button[3]',
                )
            )
        )
        driver.execute_script("arguments[0].scrollIntoView();", u_button)
        driver.execute_script("arguments[0].click();", u_button)

        # Pagination and table scraping
        table_xpath = '//*[@id="root"]/ion-app/ion-content/div/div/div[3]/div[1]/table'
        next_button_xpath = (
            "//button[contains(@class, 'aum-prev-next-btn')]//span[contains(text(),'next')]"
        )

        df_all = pd.DataFrame()

        while True:
            try:
                # Wait for table and scrape data
                table = wait.until(
                    EC.presence_of_element_located((By.XPATH, table_xpath))
                )
                soup = BeautifulSoup(
                    table.get_attribute("outerHTML"), "html.parser"
                )
                df_page = pd.read_html(StringIO(str(soup)))[0]
                df_all = pd.concat([df_all, df_page], ignore_index=True)

                # Remember a unique cell's text to detect table update
                prev_first_cell_text = df_page.iloc[0, 0]

                # Try to find and click the next button
                next_button = driver.find_element(By.XPATH, next_button_xpath)
                if not next_button.is_enabled():
                    print("Next button is disabled — reached last page.")
                    break

                driver.execute_script(
                    "arguments[0].scrollIntoView(true);", next_button
                )
                next_button.click()

                # Wait until table content changes (pagination success)
                def table_updated(drv):
                    try:
                        new_table = drv.find_element(By.XPATH, table_xpath)
                        new_soup = BeautifulSoup(
                            new_table.get_attribute("outerHTML"), "html.parser"
                        )
                        new_df = pd.read_html(StringIO(str(new_soup)))[0]
                        return new_df.iloc[0, 0] != prev_first_cell_text
                    except Exception:
                        return False

                wait.until(table_updated)

                # Optional: random delay for more human-like scraping
                time.sleep(random.uniform(1, 3))

            except (TimeoutException, NoSuchElementException):
                print("No further pages or next button not found. Scraping complete.")
                break
            except StaleElementReferenceException:
                print("Encountered stale element, retrying...")
                time.sleep(2)
                continue

        print("Completed scraping all pages.")
        print(df_all)

        # Data processing
        df_all["Aggregate"] = df_all[
            ["Available Bal", "Points W/L", "Exposure", "Lifetime Profit"]
        ].sum(axis=1)

        df_final = df_all[df_all["Aggregate"] == 0].copy()

        df_final["language"] = "Hindi"
        df_final["Website Name"] = "winfix.fun"
        df_final["Account Id"] = df_final["Username"]
        df_final["Lead Source 2"] = "META DA-Meta"

        df_final["Username"] = df_final["Username"].str[:-4]
        df_final["Account Id"] = df_final["Account Id"].str[:-4]

        df_final = df_final[
            [
                "phoneNumber",
                "Username",
                "Lead Source 2",
                "language",
                "Website Name",
                "Account Id",
                "Created Time",
            ]
        ].reset_index(drop=True)

        # Save to CSV: create directory if missing
        output_path = r"C:\Users\Akhil\Desktop\scrap\Dark_Adverse.csv"
        output_dir = os.path.dirname(output_path)

        # Recursively create the directory if it does not exist
        os.makedirs(output_dir, exist_ok=True)  # [web:11][web:14][web:17]

        df_final.to_csv(output_path, index=False)
        print(f"Saved CSV to: {output_path}")

    finally:
        driver.quit()


if __name__ == "__main__":
    main()
