import tkinter as tk
from tkinter import ttk, scrolledtext
import subprocess
import time
import os
import threading
from datetime import datetime
import glob
from PIL import Image, ImageTk

BASE_DIR = r"C:\Users\Akhil\Downloads\p1\p1"
LOGO_PATH = r"C:\Users\Akhil\Downloads\p1\tag\Vikrant_tag.png"
compiler_script = "Compiler.py"
modem_script = "modem_reboot.py"

class ScriptLauncherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Vikrant Scrap Launcher v2.0")
        self.root.geometry("1100x800")
        
        self.processes = {}
        self.modem_process = None
        self.compiler_process = None
        self.is_running = False
        self.launch_thread = None
        self.timer_running = False
        self.timer_interval = 3600
        
        # Auto-detect Python scripts
        self.scripts = self.detect_scripts()
        
        self.setup_ui()
        self.start_progress_monitor()
    
    def detect_scripts(self):
        """Automatically detect all .py files in BASE_DIR (excluding compiler and modem)"""
        pattern = os.path.join(BASE_DIR, "*.py")
        all_py_files = glob.glob(pattern)
        
        scripts = []
        for file_path in all_py_files:
            filename = os.path.basename(file_path)
            if filename not in [compiler_script, modem_script]:
                scripts.append(filename)
        
        scripts.sort()
        return scripts
    
    def start_progress_monitor(self):
        """Continuously monitor ALL processes for progress"""
        def monitor_loop():
            while True:
                self.root.after(0, self.update_progress_bar)
                time.sleep(1)
        
        threading.Thread(target=monitor_loop, daemon=True).start()
    
    def setup_ui(self):
        # Header frame with logo and title
        header_frame = ttk.Frame(self.root)
        header_frame.pack(fill="x", padx=10, pady=(10,5))
        
        # Logo frame (left side)
        logo_frame = ttk.Frame(header_frame)
        logo_frame.pack(side="left", padx=(0,10))
        
        try:
            # Load and resize logo
            logo_image = Image.open(LOGO_PATH)
            logo_image = logo_image.resize((80, 80), Image.Resampling.LANCZOS)
            self.logo_photo = ImageTk.PhotoImage(logo_image)
            
            logo_label = ttk.Label(logo_frame, image=self.logo_photo)
            logo_label.pack()
        except Exception as e:
            # Fallback if logo fails to load
            logo_label = ttk.Label(logo_frame, text="🛸", font=("Arial", 48))
            logo_label.pack()
        
        # Title frame (right side)
        title_frame = ttk.Frame(header_frame)
        title_frame.pack(side="right", fill="x", expand=True)
        
        title_label = ttk.Label(title_frame, text="Vikrant Scrap Launcher v2.0", 
                               font=("Arial", 24, "bold"))
        title_label.pack(anchor="e")
        
        subtitle_label = ttk.Label(title_frame, text="Beta Version (partial automation)", 
                                 font=("Arial", 12), foreground="gray")
        subtitle_label.pack(anchor="e")
        
        # Separator
        ttk.Separator(self.root, orient="horizontal").pack(fill="x", padx=10, pady=5)
        
        # Control frame
        control_frame = ttk.Frame(self.root)
        control_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Button(control_frame, text="🚀 Start All Scripts", 
                  command=self.start_scripts).pack(side="left", padx=5)
        ttk.Button(control_frame, text="⏹️ Stop All", 
                  command=self.stop_all).pack(side="left", padx=5)
        ttk.Button(control_frame, text="📊 Refresh Status", 
                  command=self.refresh_status).pack(side="left", padx=5)
        
        ttk.Button(control_frame, text="📶 Reboot Modem", 
                  command=self.run_modem_reboot).pack(side="right", padx=5)
        
        # Timer frame
        timer_frame = ttk.LabelFrame(self.root, text="Auto Reschedule Timer", padding=10)
        timer_frame.pack(fill="x", padx=10, pady=5)
        
        timer_inner = ttk.Frame(timer_frame)
        timer_inner.pack(fill="x")
        
        ttk.Label(timer_inner, text="Interval:").pack(side="left")
        
        # Dropdown for time units
        self.time_unit_var = tk.StringVar(value="hours")
        time_unit_combo = ttk.Combobox(timer_inner, textvariable=self.time_unit_var, 
                                     values=["seconds", "minutes", "hours"], 
                                     state="readonly", width=8)
        time_unit_combo.pack(side="left", padx=5)
        
        # Editable field for the selected unit
        self.interval_value_var = tk.StringVar(value="1")
        interval_entry = ttk.Entry(timer_inner, textvariable=self.interval_value_var, width=8)
        interval_entry.pack(side="left", padx=5)
        
        # Dynamic label that shows current unit
        self.unit_label = ttk.Label(timer_inner, text="")
        self.unit_label.pack(side="left", padx=(0,5))
        
        # Update unit label when dropdown changes
        self.time_unit_var.trace('w', self.update_unit_label)
        self.update_unit_label()
        
        ttk.Button(timer_inner, text="🔄 Start Timer", 
                  command=self.toggle_timer).pack(side="left", padx=5)
        self.timer_status = ttk.Label(timer_inner, text="OFF", foreground="red")
        self.timer_status.pack(side="left", padx=10)
        
        # Individual script buttons frame
        scripts_frame = ttk.LabelFrame(self.root, text="Individual Scripts", padding=10)
        scripts_frame.pack(fill="x", padx=10, pady=5)
        
        self.script_buttons = {}
        button_frame = ttk.Frame(scripts_frame)
        button_frame.pack(fill="x")
        
        for script in self.scripts:
            btn = ttk.Button(button_frame, text=f"▶️ {script}", 
                           command=lambda s=script: self.run_single_script(s))
            btn.pack(side="left", padx=5, pady=5)
            self.script_buttons[script] = btn
        
        # Progress frame
        progress_frame = ttk.LabelFrame(self.root, text="Progress", padding=10)
        progress_frame.pack(fill="x", padx=10, pady=5)
        
        self.overall_progress = ttk.Progressbar(progress_frame, mode='determinate', maximum=100)
        self.overall_progress.pack(fill="x", pady=5)
        
        progress_label_frame = ttk.Frame(progress_frame)
        progress_label_frame.pack(fill="x", pady=5)
        self.progress_label = ttk.Label(progress_label_frame, text="0/0 (0%)")
        self.progress_label.pack()
        
        # Script status listbox
        list_frame = ttk.LabelFrame(self.root, text="Script Status", padding=10)
        list_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        columns = ('Script', 'Status', 'PID', 'Elapsed')
        self.status_tree = ttk.Treeview(list_frame, columns=columns, show='headings', height=10)
        for col in columns:
            self.status_tree.heading(col, text=col)
            self.status_tree.column(col, width=180)
        self.status_tree.pack(fill="both", expand=True)
        
        # Log window
        log_frame = ttk.LabelFrame(self.root, text="Live Logs", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.log_text = scrolledtext.ScrolledText(log_frame, height=8, state='disabled')
        self.log_text.pack(fill="both", expand=True)
    
    def update_unit_label(self, *args):
        """Update the unit label based on dropdown selection"""
        unit = self.time_unit_var.get()
        if unit == "seconds":
            self.unit_label.config(text="s")
        elif unit == "minutes":
            self.unit_label.config(text="m")
        elif unit == "hours":
            self.unit_label.config(text="h")
    
    def parse_timer_interval(self):
        """Parse timer interval from dropdown + value entry"""
        try:
            value = int(self.interval_value_var.get())
            unit = self.time_unit_var.get()
            
            if unit == "hours":
                return value * 3600
            elif unit == "minutes":
                return value * 60
            elif unit == "seconds":
                return value
        except:
            pass
        return 3600  # Default 1 hour
    
    def toggle_timer(self):
        """Start/Stop auto-reschedule timer"""
        if self.timer_running:
            self.timer_running = False
            self.timer_status.config(text="OFF", foreground="red")
            self.log_message("⏹️ Auto-reschedule timer STOPPED")
        else:
            self.timer_interval = self.parse_timer_interval()
            self.timer_running = True
            self.timer_status.config(text="ON", foreground="green")
            unit = self.time_unit_var.get()
            value = self.interval_value_var.get()
            self.log_message(f"🔄 Timer STARTED: {value} {unit} ({self.timer_interval//60}m)")
            self.schedule_next_run()
    
    def schedule_next_run(self):
        """Schedule next full batch run"""
        if not self.timer_running:
            return
        
        def run_batch():
            if self.is_running:
                self.log_message("⚠️ Batch running, skipping timer...")
            else:
                self.log_message("🔄 Timer triggered - Starting full batch!")
                self.start_scripts()
            
            if self.timer_running:
                self.root.after(self.timer_interval * 1000, self.schedule_next_run)
        
        self.root.after(self.timer_interval * 1000, run_batch)
    
    def update_progress_bar(self):
        """Update progress bar based on STARTED scripts only"""
        if not self.processes:
            if hasattr(self, 'overall_progress'):
                self.overall_progress['value'] = 0
            if hasattr(self, 'progress_label'):
                self.progress_label.config(text="0/0 (0%)")
            return
        
        total_started = len(self.processes)
        completed = sum(1 for info in self.processes.values() 
                       if info['proc'].poll() is not None)
        
        pct = (completed / total_started) * 100 if total_started > 0 else 0
        if hasattr(self, 'overall_progress'):
            self.overall_progress['value'] = pct
        
        if hasattr(self, 'progress_label'):
            progress_text = f"{completed}/{total_started} ({pct:.0f}%)"
            self.progress_label.config(text=progress_text)
    
    def log_message(self, message):
        self.root.after(0, lambda: self._log(message))
    
    def _log(self, message):
        self.log_text.config(state='normal')
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.log_text.config(state='disabled')
    
    # [All other methods remain exactly the same...]
    def run_single_script(self, script_name):
        if script_name in self.processes:
            self.log_message(f"⚠️ {script_name} already running!")
            return
        
        script_path = os.path.join(BASE_DIR, script_name)
        try:
            p = subprocess.Popen(["python", script_path])
            self.processes[script_name] = {
                'proc': p, 'start_time': time.time()
            }
            self.log_message(f"▶️ {script_name} started (PID: {p.pid})")
            self.root.after(0, self.update_status_tree)
            
            self.script_buttons[script_name].config(state='disabled')
        except Exception as e:
            self.log_message(f"❌ Failed to start {script_name}: {e}")
    
    def run_modem_reboot(self):
        if self.modem_process and self.modem_process.poll() is None:
            self.log_message("⚠️ Modem reboot already running!")
            return
        
        modem_path = os.path.join(BASE_DIR, modem_script)
        try:
            self.modem_process = subprocess.Popen(["python", modem_path])
            self._modem_start_time = time.time()
            self.log_message(f"📶 Manual modem reboot started (PID: {self.modem_process.pid})")
            self.root.after(0, self.update_status_tree)
        except Exception as e:
            self.log_message(f"❌ Manual modem reboot failed: {e}")
    
    def start_scripts(self):
        if self.is_running:
            return
        self.is_running = True
        
        for script in list(self.processes.keys()):
            if self.processes[script]['proc'].poll() is None:
                self.processes[script]['proc'].terminate()
        self.processes.clear()
        if hasattr(self, 'overall_progress'):
            self.overall_progress['value'] = 0
        
        self.log_message("🚀 Starting script sequence...")
        self.launch_thread = threading.Thread(target=self._launch_scripts_thread)
        self.launch_thread.daemon = True
        self.launch_thread.start()
    
    def _launch_scripts_thread(self):
        for i, script in enumerate(self.scripts, 1):
            if not self.is_running:
                break
            
            script_path = os.path.join(BASE_DIR, script)
            self.log_message(f"Starting {script} ({i}/{len(self.scripts)})")
            
            try:
                p = subprocess.Popen(["python", script_path])
                self.processes[script] = {
                    'proc': p, 'start_time': time.time()
                }
                self.root.after(0, self.update_status_tree)
                
                if i < len(self.scripts):
                    self.log_message("⏳ Waiting 20 seconds before next...")
                    for _ in range(20):
                        if not self.is_running:
                            break
                        time.sleep(1)
            except Exception as e:
                self.log_message(f"❌ Failed to start {script}: {e}")
        
        if self.is_running:
            self.log_message("✅ All main scripts launched. Monitoring...")
            self.root.after(0, self.wait_for_completion)
    
    def wait_for_completion(self):
        def monitor():
            total = len(self.scripts)
            while self.is_running:
                completed = sum(1 for info in self.processes.values() 
                              if info['proc'].poll() is not None)
                if completed >= total:
                    break
                time.sleep(1)
            
            if self.is_running:
                self.log_message("🎉 All scripts finished! Launching Compiler.py...")
                self.root.after(0, self.launch_compiler)
        
        threading.Thread(target=monitor, daemon=True).start()
    
    def launch_compiler(self):
        compiler_path = os.path.join(BASE_DIR, compiler_script)
        try:
            self.compiler_process = subprocess.Popen(["python", compiler_path])
            self.compiler_start_time = time.time()
            self.log_message(f"🔨 Compiler.py launched (PID: {self.compiler_process.pid})")
            self.root.after(0, self.monitor_compiler)
        except Exception as e:
            self.log_message(f"❌ Compiler failed: {e}")
    
    def monitor_compiler(self):
        def watch_compiler():
            while self.is_running and self.compiler_process.poll() is None:
                time.sleep(1)
            
            if self.is_running:
                self.log_message("✅ Compiler finished! Auto-launching modem reboot...")
                self.auto_launch_modem()
        
        threading.Thread(target=watch_compiler, daemon=True).start()
    
    def auto_launch_modem(self):
        modem_path = os.path.join(BASE_DIR, modem_script)
        try:
            self.modem_process = subprocess.Popen(["python", modem_path])
            self._modem_start_time = time.time()
            self.log_message(f"🔄 AUTO Modem reboot started after compiler (PID: {self.modem_process.pid})")
            self.root.after(0, self.update_status_tree)
        except Exception as e:
            self.log_message(f"❌ Auto modem reboot failed: {e}")
    
    def stop_all(self):
        self.is_running = False
        
        for script, info in self.processes.items():
            if info['proc'].poll() is None:
                info['proc'].terminate()
                self.log_message(f"🛑 Stopped {script}")
                if script in self.script_buttons:
                    self.script_buttons[script].config(state='normal')
        
        if self.compiler_process and self.compiler_process.poll() is None:
            self.compiler_process.terminate()
            self.log_message("🛑 Stopped Compiler.py")
        
        if self.modem_process and self.modem_process.poll() is None:
            self.modem_process.terminate()
            self.log_message("🛑 Stopped modem reboot")
        
        self.log_message("All processes terminated.")
        self.root.after(0, self.update_status_tree)
    
    def update_status_tree(self):
        for item in self.status_tree.get_children():
            self.status_tree.delete(item)
        
        total_started = len(self.processes)
        completed_scripts = sum(1 for info in self.processes.values() 
                               if info['proc'].poll() is not None)
        if total_started > 0:
            pct = (completed_scripts / total_started) * 100
            progress_text = f"{completed_scripts}/{total_started} ({pct:.0f}%)"
        else:
            progress_text = "0/0 (0%)"
        if hasattr(self, 'progress_label'):
            self.progress_label.config(text=progress_text)
        
        for script, info in self.processes.items():
            status = 'Running' if info['proc'].poll() is None else 'Completed'
            elapsed = time.time() - info['start_time']
            pid = info['proc'].pid
            self.status_tree.insert('', 'end', values=(script, status, pid, f"{elapsed:.0f}s"))
            
            if status == 'Completed' and script in self.script_buttons:
                self.script_buttons[script].config(state='normal')
        
        if self.compiler_process:
            status = 'Running' if self.compiler_process.poll() is None else 'Completed'
            elapsed = time.time() - getattr(self, 'compiler_start_time', time.time())
            self.status_tree.insert('', 'end', values=(compiler_script, status, 
                                                     self.compiler_process.pid, f"{elapsed:.0f}s"))
        
        if self.modem_process and self.modem_process.poll() is None:
            elapsed = time.time() - getattr(self, '_modem_start_time', time.time())
            self.status_tree.insert('', 'end', values=(modem_script, 'Running', 
                                                     self.modem_process.pid, f"{elapsed:.0f}s"))
    
    def refresh_status(self):
        self.root.after(0, self.update_status_tree)
        self.log_message("Status refreshed.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ScriptLauncherApp(root)
    root.mainloop()
