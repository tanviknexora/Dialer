import os
import time
import random
import pandas as pd
from io import StringIO
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException, StaleElementReferenceException, NoSuchElementException
)
import undetected_chromedriver as uc
from selenium_stealth import stealth
from selenium.webdriver.chrome.options import Options

# -------------------------
# Human delay function
# -------------------------
def human_delay(min_seconds=2, max_seconds=5):
    delay = random.uniform(min_seconds, max_seconds)
    time.sleep(delay)

# -------------------------
# Chrome driver setup with stealth
# -------------------------
def get_driver():
    ua = UserAgent()
    options = uc.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument(f"--user-agent={ua.random}")
    driver = uc.Chrome(version_main=144, options=options)

    stealth(
        driver,
        languages=["en-US", "en"],
        vendor="Google Inc.",
        platform="Win32",
        webgl_vendor="Intel Inc.",
        renderer="Intel Iris OpenGL",
        fix_hairline=True,
    )
    return driver

# -------------------------
# Main scraping function
# -------------------------
def main():
    driver = get_driver()
    website = 'https://affiliate.winfix.fun/login'
    driver.get(website)

    # Login
    human_delay()
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div[2]/div/form/span/div/div/input').send_keys("Winfix_Billy")
    human_delay()
    driver.find_element(By.XPATH, '//*[@id="standard-adornment-password"]').send_keys("OydqyaYch4FV8")
    human_delay()
    driver.find_element(By.XPATH, '//*[@id="root"]/div[1]/div[2]/div/form/div[5]/button/span[1]').click()

    # Navigate through UI
    wait = WebDriverWait(driver, 10)
    human_delay()
    user_mgmt_button = wait.until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="root"]/ion-app/div[3]/ion-toolbar/div/div/ion-header/div/a[2]/span/span[1]'))
    )
    driver.execute_script("arguments[0].click();", user_mgmt_button)

    human_delay()
    affiliate_button = wait.until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="root"]/ion-app/ion-content/div/div/div[2]/div[2]/div'))
    )
    driver.execute_script("arguments[0].scrollIntoView();", affiliate_button)
    driver.execute_script("arguments[0].click();", affiliate_button)

    human_delay()
    u_button = wait.until(
        EC.element_to_be_clickable((By.XPATH, '//*[@id="root"]/ion-app/ion-content/div/div/div[3]/div[1]/table/tbody/tr/td[6]/button[3]'))
    )
    driver.execute_script("arguments[0].scrollIntoView();", u_button)
    driver.execute_script("arguments[0].click();", u_button)

    # Scraping table
    wait = WebDriverWait(driver, 20)
    table_xpath = '//*[@id="root"]/ion-app/ion-content/div/div/div[3]/div[1]/table'
    next_button_xpath = "//button[contains(@class, 'aum-prev-next-btn')]//span[contains(text(),'next')]"
    df_all = pd.DataFrame()

    while True:
        try:
            table = wait.until(EC.presence_of_element_located((By.XPATH, table_xpath)))
            soup = BeautifulSoup(table.get_attribute('outerHTML'), 'html.parser')
            df_page = pd.read_html(StringIO(str(soup)))[0]
            df_all = pd.concat([df_all, df_page], ignore_index=True)

            prev_first_cell_text = df_page.iloc[0, 0]

            # Next button click
            next_button = driver.find_element(By.XPATH, next_button_xpath)
            if not next_button.is_enabled():
                print("Next button is disabled — reached last page.")
                break

            driver.execute_script("arguments[0].scrollIntoView(true);", next_button)
            next_button.click()

            def table_updated(driver):
                try:
                    new_table = driver.find_element(By.XPATH, table_xpath)
                    new_soup = BeautifulSoup(new_table.get_attribute('outerHTML'), 'html.parser')
                    new_df = pd.read_html(StringIO(str(new_soup)))[0]
                    return new_df.iloc[0, 0] != prev_first_cell_text
                except Exception:
                    return False

            wait.until(table_updated)
            time.sleep(random.uniform(1, 3))

        except (TimeoutException, NoSuchElementException):
            print("No further pages or next button not found. Scraping complete.")
            break
        except StaleElementReferenceException:
            print("Encountered stale element, retrying...")
            time.sleep(2)
            continue

    print("Completed scraping all pages.")

    # Data processing
    df_all['Aggregate'] = df_all[['Available Bal', 'Points W/L', 'Exposure', 'Lifetime Profit']].sum(axis=1)
    df_final = df_all[df_all['Aggregate'] == 0].copy()
    df_final['language'] = "Hindi"
    df_final['Website Name'] = "winfix.fun"
    df_final['Account Id'] = df_final['Username']
    df_final['Lead Source 2'] = "Billy-META"
    df_final = df_final[['phoneNumber', 'Username', 'Lead Source 2', 'language', 'Website Name', 'Account Id', 'Created Time']]

    df_final['Username'] = df_final['Username'].str[:-4]
    df_final['Account Id'] = df_final['Account Id'].str[:-4]

    # -------------------------
    # Directory creation
    # -------------------------
    save_dir = r"C:\Users\Akhil\Desktop\scrap"
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, "billy_adv1.csv")
    df_final.to_csv(save_path, index=False)

    print(f"Data saved successfully to {save_path}")
    driver.quit()


if __name__ == "__main__":
    main()
